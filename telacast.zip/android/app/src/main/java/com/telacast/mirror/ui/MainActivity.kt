package com.telacast.mirror.ui

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.telacast.mirror.data.OfflineLicenseManager
import com.telacast.mirror.databinding.ActivityMainBinding
import com.telacast.mirror.service.ScreenMirrorService
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USER_NAME = "extra_user_name"
        const val EXTRA_PLAN_NAME = "extra_plan_name"
        const val EXTRA_AUTH_MODE = "extra_auth_mode"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectionManager: MediaProjectionManager
    private var isStreaming = false
    private var authMode: String = "offline"

    private val requestNotificationsPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenMirrorService::class.java).apply {
                    action = ScreenMirrorService.ACTION_START
                    putExtra(ScreenMirrorService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenMirrorService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                atualizarEstadoUi(ativo = true)
            } else {
                Toast.makeText(this, "Permissão de captura negada.", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        authMode = intent.getStringExtra(EXTRA_AUTH_MODE) ?: "offline"
        val nome = intent.getStringExtra(EXTRA_USER_NAME) ?: "Assinante"
        val plano = intent.getStringExtra(EXTRA_PLAN_NAME) ?: "Mensal Pro"
        binding.txtAssinante.text = "$nome · $plano"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        atualizarEnderecoLocal()

        binding.btnToggleStream.setOnClickListener {
            if (isStreaming) {
                pararEspelhamento()
            } else {
                iniciarSolicitacaoCaptura()
            }
        }

        binding.btnCopiarUrl.setOnClickListener {
            val url = binding.txtUrlLocal.text.toString()
            val token = ScreenMirrorService.sessionToken
            val payload = if (token.isNotBlank()) "$url · Token: $token" else url
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Jogos do Mengão App", payload))
            Toast.makeText(this, "Dados copiados para abrir na TV", Toast.LENGTH_SHORT).show()
        }

        binding.btnModoReceptor.setOnClickListener {
            val viewerIntent = Intent(this, ViewerActivity::class.java).apply {
                putExtra(EXTRA_AUTH_MODE, authMode)
            }
            startActivity(viewerIntent)
        }
    }

    override fun onResume() {
        super.onResume()
        if (authMode == "offline") {
            val offlineState = OfflineLicenseManager.getSavedLicenseState(this)
            if (!offlineState.ativo) {
                pararEspelhamento()
                Toast.makeText(
                    this,
                    offlineState.motivo ?: "Assinatura vencida. Renove para continuar.",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                return
            }
            binding.txtAssinante.text =
                "Aparelho ${offlineState.deviceCode} · ${offlineState.plano ?: "Mensal Pro"} · ${offlineState.diasRestantes}d offline"
        }
        atualizarEstadoUi(ScreenMirrorService.isRunning)
        atualizarEnderecoLocal()
    }

    private fun iniciarSolicitacaoCaptura() {
        val captureIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            projectionManager.createScreenCaptureIntent(
                MediaProjectionConfig.createConfigForUserChoice()
            )
        } else {
            projectionManager.createScreenCaptureIntent()
        }
        screenCaptureLauncher.launch(captureIntent)
    }

    private fun pararEspelhamento() {
        val stopIntent = Intent(this, ScreenMirrorService::class.java).apply {
            action = ScreenMirrorService.ACTION_STOP
        }
        startService(stopIntent)
        atualizarEstadoUi(ativo = false)
    }

    private fun atualizarEstadoUi(ativo: Boolean) {
        isStreaming = ativo
        binding.btnToggleStream.text = if (ativo) "Parar espelhamento" else "Iniciar espelhamento"
        val token = ScreenMirrorService.sessionToken
        binding.txtStatusStream.text =
            if (ativo) "Somente Smart TV · Token: $token (~20 FPS)"
            else "Aguardando início da transmissão (somente TVs)"
    }

    private fun atualizarEnderecoLocal() {
        val ip = obterIpLocalWifi() ?: "127.0.0.1"
        binding.txtUrlLocal.text = "http://$ip:${ScreenMirrorService.HTTP_PORT}"
    }

    private fun obterIpLocalWifi(): String? {
        return runCatching {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { addr -> addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress }
                ?.hostAddress
        }.getOrNull()
    }
}
