import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import express, { NextFunction, Request, Response } from 'express';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import { verifyFirebaseAdminToken } from './server/firebaseAuth.ts';
import { attachLiveRelay, getLiveBroadcastStatus } from './server/liveRelay.ts';
import {
  activateSubscriptionDays,
  createUserProfile,
  findProfileByEmail,
  findProfileById,
  getAdminWhatsapp,
  getDeviceStats,
  getPublicAppConfig,
  hasClaimedAdmin,
  listProfiles,
  listRecentPayments,
  recordPaymentLog,
  sanitizeProfile,
  setAdminWhatsapp,
  updateProfileById,
  updatePublicAppConfig,
  upsertDeviceHeartbeat,
  UserProfileRecord,
  verifyPassword,
} from './server/store.ts';
import {
  generateOfflineActivationKey,
  getPublicLicenseKey,
  listOfflineLicenses,
} from './server/license.ts';

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');

interface JwtPayload {
  sub: string;
  email: string;
  role: 'user' | 'admin';
  exp: number;
}

function signJwt(payload: Omit<JwtPayload, 'exp'>): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const fullPayload: JwtPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7,
  };
  const body = Buffer.from(JSON.stringify(fullPayload)).toString('base64url');
  const sig = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(`${header}.${body}`)
    .digest('base64url');
  return `${header}.${body}.${sig}`;
}

function verifyJwt(token: string): JwtPayload | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, body, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(`${header}.${body}`)
    .digest('base64url');

  const bufA = Buffer.from(sig);
  const bufB = Buffer.from(expectedSig);
  if (bufA.length !== bufB.length || !crypto.timingSafeEqual(bufA, bufB)) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString('utf-8')) as JwtPayload;
    if (parsed.exp < Math.floor(Date.now() / 1000)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function timingSafeStrMatch(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

interface AuthedRequest extends Request {
  authUser?: UserProfileRecord;
  googleAdmin?: { uid: string; email: string; name: string };
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ erro: 'Token JWT ausente no cabeçalho Authorization.' });
    return;
  }
  const payload = verifyJwt(header.slice(7).trim());
  if (!payload) {
    res.status(401).json({ erro: 'Token inválido ou expirado.' });
    return;
  }
  const profile = findProfileById(payload.sub);
  if (!profile) {
    res.status(404).json({ erro: 'Perfil de usuário não encontrado.' });
    return;
  }
  req.authUser = profile;
  next();
}

async function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ erro: 'Token de administrador ausente.' });
    return;
  }
  const rawToken = header.slice(7).trim();

  // 1. Tenta validar JWT local legado
  const localPayload = verifyJwt(rawToken);
  if (localPayload) {
    const profile = findProfileById(localPayload.sub);
    if (profile && profile.role === 'admin') {
      req.authUser = profile;
      next();
      return;
    }
  }

  // 2. Valida Firebase ID Token da conta Google autorizada
  const googleAdmin = await verifyFirebaseAdminToken(rawToken);
  if (googleAdmin) {
    req.googleAdmin = googleAdmin;
    next();
    return;
  }

  res.status(403).json({ erro: 'Acesso restrito ao administrador autorizado com conta Google.' });
}

function isSubscriptionValid(profile: UserProfileRecord): boolean {
  if (profile.status_assinatura !== 'ativo' || !profile.expira_em) return false;
  return new Date(profile.expira_em).getTime() > Date.now();
}

function collectProjectFiles(dirPath: string, rootPrefix: string): string[] {
  if (!fs.existsSync(dirPath)) return [];
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  const results: string[] = [];
  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name === '.next' || entry.name === 'build') {
      continue;
    }
    const full = path.join(dirPath, entry.name);
    const rel = `${rootPrefix}/${entry.name}`;
    if (entry.isDirectory()) {
      results.push(...collectProjectFiles(full, rel));
    } else {
      results.push(rel);
    }
  }
  return results.sort();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // 1. Auth: Registro e Login
  app.post('/api/auth/register', (req, res) => {
    const { nome, email, password, plano } = req.body as {
      nome?: string;
      email?: string;
      password?: string;
      plano?: string;
    };

    if (!nome?.trim() || !email?.trim() || !password || password.length < 6) {
      res.status(400).json({ erro: 'Informe nome, e-mail válido e senha com no mínimo 6 caracteres.' });
      return;
    }

    try {
      const created = createUserProfile({
        nome,
        email,
        password,
        role: 'user',
        plano: plano || '1 Mês',
      });
      const token = signJwt({ sub: created.id, email: created.email, role: created.role });
      res.status(201).json({ token, profile: sanitizeProfile(created) });
    } catch (err) {
      res.status(409).json({ erro: err instanceof Error ? err.message : 'Erro ao cadastrar.' });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body as { email?: string; password?: string };
    if (!email?.trim() || !password) {
      res.status(400).json({ erro: 'Informe e-mail e senha.' });
      return;
    }

    const user = findProfileByEmail(email);
    if (!user || !user.passwordHash || !verifyPassword(password, user.passwordHash)) {
      res.status(401).json({ erro: 'E-mail ou senha inválidos.' });
      return;
    }

    const token = signJwt({ sub: user.id, email: user.email, role: user.role });
    res.json({ token, profile: sanitizeProfile(user) });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    res.json({ profile: sanitizeProfile(req.authUser!) });
  });

  // 2. Bootstrap legado (mantido para compatibilidade)
  app.get('/api/admin/bootstrap-status', (_req, res) => {
    res.json({
      claimed: hasClaimedAdmin(),
      envPasscodeSet: Boolean(process.env.ADMIN_PASSCODE?.trim()),
    });
  });

  app.post('/api/admin/claim', (req, res) => {
    const { nome, email, password, passcode } = req.body as {
      nome?: string;
      email?: string;
      password?: string;
      passcode?: string;
    };

    const envPasscode = process.env.ADMIN_PASSCODE?.trim();
    if (envPasscode) {
      if (!passcode || !timingSafeStrMatch(passcode, envPasscode)) {
        res.status(403).json({ erro: 'Código de administrador inválido.' });
        return;
      }
      const adminEmail = email?.trim() || 'admin@jogosdomengao.app';
      let admin = findProfileByEmail(adminEmail);
      if (!admin) {
        admin = createUserProfile({
          nome: nome?.trim() || 'Administrador',
          email: adminEmail,
          password: password && password.length >= 6 ? password : envPasscode,
          role: 'admin',
          plano: '1 Ano',
        });
      } else if (admin.role !== 'admin') {
        admin = updateProfileById(admin.id, (c) => ({ ...c, role: 'admin' }))!;
      }
      const token = signJwt({ sub: admin.id, email: admin.email, role: 'admin' });
      res.json({ token, profile: sanitizeProfile(admin) });
      return;
    }

    if (hasClaimedAdmin()) {
      res.status(409).json({ erro: 'Administrador já configurado. Faça login normalmente.' });
      return;
    }

    if (!nome?.trim() || !email?.trim() || !password || password.length < 6) {
      res.status(400).json({ erro: 'Informe nome, e-mail e senha (mínimo 6 caracteres).' });
      return;
    }

    try {
      const admin = createUserProfile({
        nome,
        email,
        password,
        role: 'admin',
        plano: '1 Ano',
      });
      const token = signJwt({ sub: admin.id, email: admin.email, role: 'admin' });
      res.status(201).json({ token, profile: sanitizeProfile(admin) });
    } catch (err) {
      res.status(400).json({ erro: err instanceof Error ? err.message : 'Erro ao criar admin.' });
    }
  });

  // 3. Verificação de assinatura para o aplicativo Android (/api/verificar-assinatura)
  const handleVerifySubscription = (req: AuthedRequest, res: Response) => {
    const safe = sanitizeProfile(req.authUser!);
    const ativo = isSubscriptionValid(req.authUser!);
    res.json({
      ativo,
      status_assinatura: safe.status_assinatura,
      plano: safe.plano,
      expira_em: safe.expira_em,
      dias_restantes: safe.dias_restantes,
      nome: safe.nome,
    });
  };
  app.get('/api/verificar-assinatura', requireAuth, handleVerifySubscription);
  app.post('/api/verificar-assinatura', requireAuth, handleVerifySubscription);

  // 4. Webhook de pagamento
  app.post('/api/webhook-pagamento', (req, res) => {
    const configuredSecret = process.env.PAYMENT_WEBHOOK_SECRET?.trim();
    const asaasHeader = req.headers['asaas-access-token'];
    const mpSig = req.headers['x-signature'];

    if (configuredSecret) {
      const validAsaas =
        typeof asaasHeader === 'string' && timingSafeStrMatch(asaasHeader, configuredSecret);
      let validMp = false;
      if (typeof mpSig === 'string') {
        const dataId = String(req.body?.data?.id ?? req.body?.id ?? '');
        const reqId = String(req.headers['x-request-id'] ?? '');
        const parts = Object.fromEntries(
          mpSig.split(',').map((p) => p.trim().split('=') as [string, string])
        );
        if (parts.ts && parts.v1 && dataId) {
          const manifest = `id:${dataId};request-id:${reqId};ts:${parts.ts};`;
          const expected = crypto
            .createHmac('sha256', configuredSecret)
            .update(manifest)
            .digest('hex');
          validMp = timingSafeStrMatch(parts.v1, expected);
        }
      }

      if (!validAsaas && !validMp) {
        res.status(401).json({ erro: 'Assinatura de webhook inválida.' });
        return;
      }
    }

    const body = req.body as Record<string, unknown>;
    const eventType = String(body.event ?? body.action ?? body.type ?? '');
    const paymentObj = (body.payment as Record<string, unknown> | undefined) ?? {};
    const statusStr = String(paymentObj.status ?? body.status ?? '').toLowerCase();

    const approved =
      eventType === 'PAYMENT_CONFIRMED' ||
      eventType === 'PAYMENT_RECEIVED' ||
      statusStr === 'approved' ||
      statusStr === 'confirmed' ||
      statusStr === 'received';

    if (!approved) {
      res.json({ ignored: true, motivo: 'Evento não representa pagamento aprovado.' });
      return;
    }

    const externalRef = String(paymentObj.externalReference ?? body.external_reference ?? '').trim();
    const payerEmail = String(
      (body.payer as Record<string, unknown> | undefined)?.email ??
        paymentObj.customerEmail ??
        body.email ??
        ''
    )
      .trim()
      .toLowerCase();
    const plano = String(body.plano ?? paymentObj.description ?? '1 Mês');
    const eventoId = String(body.id ?? paymentObj.id ?? crypto.randomUUID());

    const profile = externalRef ? findProfileById(externalRef) : findProfileByEmail(payerEmail);
    if (!profile) {
      res.status(404).json({ erro: 'Assinante não encontrado.' });
      return;
    }

    const isNew = recordPaymentLog({
      user_id: profile.id,
      gateway: typeof asaasHeader === 'string' ? 'asaas' : 'mercadopago',
      evento_id: eventoId,
      plano,
      status: 'aprovado',
    });

    if (!isNew) {
      res.json({ ok: true, idempotent: true });
      return;
    }

    const updated = activateSubscriptionDays(profile.id, 30, plano)!;
    res.json({
      ok: true,
      profile: sanitizeProfile(updated),
    });
  });

  // 5. Telemetria de dispositivos usando o app Jogos do Mengão
  app.post('/api/app/heartbeat', (req, res) => {
    const { deviceCode, platform, isTv, licenseActive, planName, isStreaming } = req.body as {
      deviceCode?: string;
      platform?: string;
      isTv?: boolean;
      licenseActive?: boolean;
      planName?: string | null;
      isStreaming?: boolean;
    };

    if (!deviceCode?.trim()) {
      res.status(400).json({ erro: 'deviceCode ausente.' });
      return;
    }

    try {
      const record = upsertDeviceHeartbeat({
        deviceCode,
        platform: platform || 'pwa',
        isTv: Boolean(isTv),
        licenseActive: Boolean(licenseActive),
        planName: planName || null,
        isStreaming: Boolean(isStreaming),
      });
      res.json({ ok: true, device: record });
    } catch (err) {
      res.status(400).json({ erro: err instanceof Error ? err.message : 'Dados inválidos.' });
    }
  });

  app.get('/api/admin/dispositivos', requireAdmin, (_req, res) => {
    res.json(getDeviceStats());
  });

  // 6. Rotas administrativas (/api/admin/*)
  app.get('/api/admin/usuarios', requireAdmin, (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const usuarios = listProfiles(q);
    const pagamentos = listRecentPayments();
    res.json({ usuarios, pagamentos });
  });

  app.post('/api/admin/usuarios/:id/renovar', requireAdmin, (req, res) => {
    const rawDays = Number((req.body as { dias?: number } | undefined)?.dias);
    const days = rawDays === 7 || rawDays === 30 || rawDays === 90 ? rawDays : 30;
    const updated = activateSubscriptionDays(String(req.params.id), days);
    if (!updated) {
      res.status(404).json({ erro: 'Usuário não encontrado.' });
      return;
    }
    res.json({ usuario: sanitizeProfile(updated) });
  });

  app.post('/api/admin/usuarios/:id/bloquear', requireAdmin, (req, res) => {
    const updated = updateProfileById(String(req.params.id), (c) => ({
      ...c,
      status_assinatura: c.status_assinatura === 'bloqueado' ? 'vencido' : 'bloqueado',
    }));
    if (!updated) {
      res.status(404).json({ erro: 'Usuário não encontrado.' });
      return;
    }
    res.json({ usuario: sanitizeProfile(updated) });
  });

  app.patch('/api/admin/usuarios/:id/plano', requireAdmin, (req, res) => {
    const { plano } = req.body as { plano?: string };
    if (!plano?.trim()) {
      res.status(400).json({ erro: 'Plano inválido.' });
      return;
    }
    const updated = updateProfileById(String(req.params.id), (c) => ({
      ...c,
      plano: plano.trim().slice(0, 60),
    }));
    if (!updated) {
      res.status(404).json({ erro: 'Usuário não encontrado.' });
      return;
    }
    res.json({ usuario: sanitizeProfile(updated) });
  });

  // 6b. Config pública (WhatsApp, Pix, trava anti-retransmissão) e Licenciamento Offline
  app.get('/api/config/whatsapp', (_req, res) => {
    res.json({ whatsappNumber: getAdminWhatsapp() });
  });

  app.get('/api/config/public', (_req, res) => {
    res.json(getPublicAppConfig());
  });

  app.get('/api/live/status', (_req, res) => {
    res.json(getLiveBroadcastStatus());
  });

  app.patch('/api/admin/config-whatsapp', requireAdmin, (req, res) => {
    const { whatsappNumber } = req.body as { whatsappNumber?: string };
    const saved = setAdminWhatsapp(whatsappNumber || '');
    res.json({ whatsappNumber: saved });
  });

  app.patch('/api/admin/config-public', requireAdmin, (req, res) => {
    const body = req.body as {
      whatsappNumber?: string;
      pixKey?: string;
      pixType?: string;
      pixReceiverName?: string;
      tvOnlyAntiRetransmission?: boolean;
    };
    const updated = updatePublicAppConfig(body);
    res.json(updated);
  });

  app.get('/api/licenca/chave-publica', (_req, res) => {
    res.json({
      ...getPublicLicenseKey(),
      whatsappNumber: getAdminWhatsapp(),
      tvOnlyAntiRetransmission: getPublicAppConfig().tvOnlyAntiRetransmission,
    });
  });

  app.get('/api/admin/chaves-offline', requireAdmin, (_req, res) => {
    res.json({ chaves: listOfflineLicenses(), whatsappNumber: getAdminWhatsapp() });
  });

  app.post('/api/admin/gerar-chave-offline', requireAdmin, (req, res) => {
    const { deviceCode, dias, validade_ate, plano } = req.body as {
      deviceCode?: string;
      dias?: number;
      validade_ate?: string;
      plano?: string;
    };
    if (!deviceCode?.trim()) {
      res.status(400).json({ erro: 'Informe o código do aparelho (ex: TC-A1B2-C3D4).' });
      return;
    }
    try {
      const record = generateOfflineActivationKey({
        deviceCode,
        dias: Number(dias) || 30,
        validade_ate,
        plano: plano?.trim() || '1 Mês',
      });
      res.status(201).json({ chave: record });
    } catch (err) {
      res.status(400).json({ erro: err instanceof Error ? err.message : 'Erro ao gerar chave.' });
    }
  });

  // 7. Explorador de código /web, /android e /webos + downloads (.apk, webOS e .zip)
  app.get('/api/projeto/arvore', (_req, res) => {
    const webFiles = collectProjectFiles(path.resolve(process.cwd(), 'web'), 'web');
    const androidFiles = collectProjectFiles(path.resolve(process.cwd(), 'android'), 'android');
    const webosFiles = collectProjectFiles(path.resolve(process.cwd(), 'webos'), 'webos');
    res.json({ files: [...webFiles, ...androidFiles, ...webosFiles] });
  });

  app.get('/api/projeto/arquivo', (req, res) => {
    const relPath = typeof req.query.path === 'string' ? req.query.path : '';
    const allowedRoots = [
      path.resolve(process.cwd(), 'web'),
      path.resolve(process.cwd(), 'android'),
      path.resolve(process.cwd(), 'webos'),
    ];
    const resolved = path.resolve(process.cwd(), relPath);
    const isAllowed = allowedRoots.some((root) => resolved.startsWith(root + path.sep));
    if (!isAllowed || !fs.existsSync(resolved) || fs.statSync(resolved).isDirectory()) {
      res.status(400).json({ erro: 'Arquivo inválido ou fora do escopo.' });
      return;
    }
    if (resolved.endsWith('.png') || resolved.endsWith('.jpg')) {
      res.json({ path: relPath, content: `[Arquivo de imagem binário: ${relPath}]` });
      return;
    }
    const content = fs.readFileSync(resolved, 'utf-8');
    res.json({ path: relPath, content });
  });

  app.get('/api/download-projeto', async (_req, res) => {
    const zip = new JSZip();
    const allFiles = [
      ...collectProjectFiles(path.resolve(process.cwd(), 'web'), 'web'),
      ...collectProjectFiles(path.resolve(process.cwd(), 'android'), 'android'),
      ...collectProjectFiles(path.resolve(process.cwd(), 'webos'), 'webos'),
    ];
    for (const rel of allFiles) {
      const abs = path.resolve(process.cwd(), rel);
      zip.file(rel, fs.readFileSync(abs));
    }
    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="JogosDoMengao-SaaS-Web-Android-TV.zip"');
    res.send(buffer);
  });

  app.get('/api/download-webos', async (_req, res) => {
    const zip = new JSZip();
    const webosFiles = collectProjectFiles(path.resolve(process.cwd(), 'webos'), 'webos');
    for (const rel of webosFiles) {
      const innerName = rel.replace(/^webos\//, '');
      zip.file(innerName, fs.readFileSync(path.resolve(process.cwd(), rel)));
    }
    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="JogosDoMengao-LG-webOS.zip"');
    res.send(buffer);
  });

  app.get('/api/download-apk', async (_req, res) => {
    const zip = new JSZip();
    zip.file(
      'META-INF/MANIFEST.MF',
      'Manifest-Version: 1.0\nCreated-By: Jogos do Mengao Build Packaging\nApplication-Id: com.telacast.mirror\nVersion-Name: 1.0.0\n'
    );
    zip.file(
      'README-COMPILAR-APK.txt',
      [
        'Jogos do Mengão Android & Android TV (Kotlin + Leanback + Proteção Anti-Retransmissão)',
        'Abra a pasta /android no Android Studio e execute ./gradlew assembleRelease',
        'para gerar o APK assinado compatível com Celulares e Android TV.',
      ].join('\n')
    );
    const androidFiles = collectProjectFiles(path.resolve(process.cwd(), 'android'), 'android');
    for (const rel of androidFiles) {
      zip.file(rel, fs.readFileSync(path.resolve(process.cwd(), rel)));
    }
    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="JogosDoMengao-v1.0.0.apk"');
    res.send(buffer);
  });

  // 8. Vite dev middleware ou static production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const server = http.createServer(app);
  attachLiveRelay(server);

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Jogos do Mengão server listening on http://localhost:${PORT}`);
  });
}

startServer();
