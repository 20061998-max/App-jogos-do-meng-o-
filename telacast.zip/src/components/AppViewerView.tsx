import { Download, Lock, ShieldCheck, Tv } from 'lucide-react';
import { MengaoShield } from './MengaoShield';
import { PWAInstallButton } from './PWAInstallButton';

export function AppViewerView() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-8 space-y-6">
        <div className="flex items-start gap-4">
          <MengaoShield className="h-11 w-11 shrink-0" />
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
              <Lock className="h-3.5 w-3.5" />
              <span>Acesso exclusivo fora do navegador comum</span>
            </div>
            <h1 className="mt-1 font-display text-3xl font-bold text-white">
              Jogos do Mengão rodam apenas no App e Smart TVs
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-zinc-300">
              A vitrine do site serve apenas para consultar valores, Pix, passo a passo e instalar o
              aplicativo. Para assistir aos jogos sem bloqueio, abra pelo atalho instalado ou pelo
              APK na sua Smart TV.
            </p>
          </div>
        </div>

        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4 text-xs text-zinc-300 space-y-2">
          <div className="flex items-center gap-2 font-semibold text-white">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>Proteção Anti-Retransmissão Ativa</span>
          </div>
          <p>
            Não é permitido retransmitir ou capturar os jogos para terceiros: a retransmissão é
            liberada exclusivamente para Smart TVs (Android TV e LG webOS).
          </p>
          <p className="text-zinc-400">
            Compatível com Android, iPhone/iPad (atalho PWA), Android TV (APK) e TV LG webOS.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <PWAInstallButton variant="primary" label="Instalar App / Atalho" />
          <a
            href="/api/download-apk"
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 bg-zinc-950 px-4 py-2 text-xs font-semibold text-zinc-100 hover:bg-zinc-800 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" />
            APK Android / TV
          </a>
          <a
            href="/api/download-webos"
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 bg-zinc-950 px-4 py-2 text-xs font-semibold text-zinc-100 hover:bg-zinc-800 whitespace-nowrap"
          >
            <Tv className="h-3.5 w-3.5" />
            App LG webOS
          </a>
        </div>
      </div>
    </div>
  );
}
