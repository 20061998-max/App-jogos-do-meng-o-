import { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  Check,
  Copy,
  KeyRound,
  Lock,
  LogOut,
  MessageCircle,
  Plus,
  RefreshCw,
  Save,
  ShieldCheck,
  Trash2,
  Tv,
  Users,
} from 'lucide-react';
import {
  ADMIN_EMAIL,
  auth,
  isAuthorizedAdminUser,
  signInWithGoogleAccount,
  signOutGoogleAccount,
} from '../lib/firebase';
import {
  AppSettingsDoc,
  deletePlanById,
  logOfflineLicenseToFirestore,
  PixType,
  PlanItem,
  savePublicSettings,
  seedDefaultCatalogIfEmpty,
  upsertPlan,
} from '../lib/storeCatalog';
import { formatDatePtBr } from '../types';
import { MengaoShield } from './MengaoShield';

interface OfflineLicenseItem {
  id: string;
  deviceCode: string;
  plano: string;
  dias: number;
  expira_em: string;
  activationKey: string;
  criado_em: string;
}

interface DeviceRecord {
  deviceCode: string;
  platform: string;
  isTv: boolean;
  licenseActive: boolean;
  planName: string;
  isStreaming: boolean;
  firstSeenAt: string;
  lastSeenAt: string;
}

interface DeviceStatsResponse {
  onlineAgora: number;
  totalInstalados: number;
  ativosComLicenca: number;
  tvsConectadas: number;
  transmitindoAgora: number;
  dispositivos: DeviceRecord[];
}

interface AdminViewProps {
  settings: AppSettingsDoc;
  plans: PlanItem[];
}

export function AdminView({ settings, plans }: AdminViewProps) {
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  const [deviceStats, setDeviceStats] = useState<DeviceStatsResponse>({
    onlineAgora: 0,
    totalInstalados: 0,
    ativosComLicenca: 0,
    tvsConectadas: 0,
    transmitindoAgora: 0,
    dispositivos: [],
  });
  const [loadingStats, setLoadingStats] = useState(false);

  // Settings form state
  const [formSettings, setFormSettings] = useState<AppSettingsDoc>(settings);
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState<string | null>(null);

  // Plans management state
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [planDraft, setPlanDraft] = useState<PlanItem | null>(null);
  const [planFeaturesText, setPlanFeaturesText] = useState('');
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanPrice, setNewPlanPrice] = useState('');
  const [newPlanDays, setNewPlanDays] = useState(30);
  const [newPlanSubtitle, setNewPlanSubtitle] = useState('');
  const [newPlanFeatures, setNewPlanFeatures] = useState('');
  const [savingPlan, setSavingPlan] = useState(false);
  const [planFeedback, setPlanFeedback] = useState<string | null>(null);

  // Offline key generator state
  const [deviceCodeInput, setDeviceCodeInput] = useState('');
  const [offlineDays, setOfflineDays] = useState<number>(30);
  const [validadeDate, setValidadeDate] = useState<string>(() => {
    const d = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    return d.toISOString().slice(0, 10);
  });
  const [offlinePlan, setOfflinePlan] = useState('1 Mês');
  const [generatedKey, setGeneratedKey] = useState<OfflineLicenseItem | null>(null);
  const [offlineKeys, setOfflineKeys] = useState<OfflineLicenseItem[]>([]);
  const [offlineError, setOfflineError] = useState<string | null>(null);
  const [generatingKey, setGeneratingKey] = useState(false);
  const [copiedGenerated, setCopiedGenerated] = useState(false);

  const isAuthorizedAdmin = isAuthorizedAdminUser(googleUser);

  useEffect(() => {
    setFormSettings(settings);
  }, [settings]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setGoogleUser(user);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  async function fetchAdminServerData() {
    if (!googleUser || !isAuthorizedAdmin) return;
    setLoadingStats(true);
    try {
      const idToken = await googleUser.getIdToken();
      const [statsRes, keysRes] = await Promise.all([
        fetch('/api/admin/dispositivos', {
          headers: { Authorization: `Bearer ${idToken}` },
        }),
        fetch('/api/admin/chaves-offline', {
          headers: { Authorization: `Bearer ${idToken}` },
        }),
      ]);
      if (statsRes.ok) {
        setDeviceStats((await statsRes.json()) as DeviceStatsResponse);
      }
      if (keysRes.ok) {
        const keyData = await keysRes.json();
        setOfflineKeys(keyData.chaves ?? []);
      }
    } finally {
      setLoadingStats(false);
    }
  }

  useEffect(() => {
    if (!isAuthorizedAdmin || !googleUser) return;
    googleUser.getIdToken().then((idToken) => {
      void seedDefaultCatalogIfEmpty(idToken).catch(() => undefined);
    });
    void fetchAdminServerData();
    const interval = window.setInterval(() => {
      void fetchAdminServerData();
    }, 15000);
    return () => window.clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthorizedAdmin, googleUser?.uid]);

  async function handleGoogleSignIn() {
    setAuthError(null);
    setAuthLoading(true);
    try {
      const user = await signInWithGoogleAccount();
      if (!isAuthorizedAdminUser(user)) {
        setAuthError(
          `A conta ${user.email || 'selecionada'} não é a conta administradora autorizada (${ADMIN_EMAIL}).`
        );
      }
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Falha ao entrar com Google.');
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleSaveSettings(e: React.FormEvent) {
    e.preventDefault();
    if (!googleUser) return;
    setSavingSettings(true);
    setSettingsMsg(null);
    try {
      const idToken = await googleUser.getIdToken();
      await savePublicSettings(formSettings, idToken);
      setSettingsMsg('Configurações salvas no Firebase e atualizadas na vitrine!');
    } catch (err) {
      setSettingsMsg(err instanceof Error ? err.message : 'Erro ao salvar configurações.');
    } finally {
      setSavingSettings(false);
    }
  }

  function startEditingPlan(plan: PlanItem) {
    setEditingPlanId(plan.id);
    setPlanDraft({ ...plan });
    setPlanFeaturesText(plan.features.join('\n'));
    setPlanFeedback(null);
  }

  async function handleSaveEditedPlan(e: React.FormEvent) {
    e.preventDefault();
    if (!planDraft) return;
    setSavingPlan(true);
    setPlanFeedback(null);
    try {
      const updated: PlanItem = {
        ...planDraft,
        features: planFeaturesText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean)
          .slice(0, 8),
      };
      await upsertPlan(updated);
      setEditingPlanId(null);
      setPlanDraft(null);
      setPlanFeedback(`Plano "${updated.name}" atualizado na vitrine!`);
    } finally {
      setSavingPlan(false);
    }
  }

  async function handleCreateNewPlan(e: React.FormEvent) {
    e.preventDefault();
    if (!newPlanName.trim() || !newPlanPrice.trim()) return;
    setSavingPlan(true);
    setPlanFeedback(null);
    try {
      const slug = `plan-${newPlanName
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString().slice(-4)}`;
      const item: PlanItem = {
        id: slug,
        name: newPlanName.trim(),
        subtitle: newPlanSubtitle.trim() || 'Plano personalizado do Mengão',
        priceText: newPlanPrice.trim(),
        days: Math.max(0, Math.min(3650, Math.floor(newPlanDays))),
        periodLabel: '· Pix ou WhatsApp',
        features: newPlanFeatures
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean)
          .slice(0, 8),
        featured: false,
        active: true,
        sortOrder: plans.length + 1,
      };
      await upsertPlan(item);
      setNewPlanName('');
      setNewPlanPrice('');
      setNewPlanDays(30);
      setNewPlanSubtitle('');
      setNewPlanFeatures('');
      setPlanFeedback(`Novo plano "${item.name}" adicionado na vitrine!`);
    } finally {
      setSavingPlan(false);
    }
  }

  async function handleDeletePlan(planId: string, planName: string) {
    setSavingPlan(true);
    setPlanFeedback(null);
    try {
      await deletePlanById(planId);
      if (editingPlanId === planId) {
        setEditingPlanId(null);
        setPlanDraft(null);
      }
      setPlanFeedback(`Plano "${planName}" removido.`);
    } finally {
      setSavingPlan(false);
    }
  }

  function handleDaysPresetChange(days: number) {
    setOfflineDays(days);
    if (days > 0) {
      const target = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
      setValidadeDate(target.toISOString().slice(0, 10));
    }
    if (days === 30) setOfflinePlan('1 Mês');
    else if (days === 90) setOfflinePlan('3 Meses');
    else if (days === 180) setOfflinePlan('6 Meses');
    else if (days === 365) setOfflinePlan('1 Ano');
    else setOfflinePlan('Outros');
  }

  function handleOfflinePlanSelect(planName: string) {
    setOfflinePlan(planName);
    const matched = plans.find((p) => p.name === planName);
    if (matched && matched.days > 0) {
      setOfflineDays(matched.days);
      setValidadeDate(
        new Date(Date.now() + matched.days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
      );
    } else {
      setOfflineDays(0);
    }
  }

  async function handleGenerateOfflineKey(e: React.FormEvent) {
    e.preventDefault();
    if (!googleUser) return;
    setOfflineError(null);
    setGeneratingKey(true);
    try {
      const idToken = await googleUser.getIdToken();
      const res = await fetch('/api/admin/gerar-chave-offline', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({
          deviceCode: deviceCodeInput,
          dias: offlineDays,
          validade_ate: validadeDate,
          plano: offlinePlan,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setOfflineError(data.erro || 'Não foi possível gerar a chave.');
        return;
      }
      setGeneratedKey(data.chave);
      setDeviceCodeInput('');
      await logOfflineLicenseToFirestore(data.chave).catch(() => undefined);
      await fetchAdminServerData();
    } finally {
      setGeneratingKey(false);
    }
  }

  if (!authReady) {
    return (
      <div className="mx-auto max-w-md px-6 py-20 text-center text-sm text-zinc-400">
        Verificando sessão Google...
      </div>
    );
  }

  if (!isAuthorizedAdmin) {
    return (
      <div className="mx-auto max-w-md px-6 py-16">
        <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-8 space-y-6">
          <div className="flex items-center gap-3">
            <MengaoShield className="h-10 w-10 shrink-0" />
            <div>
              <h1 className="font-display text-2xl font-bold text-white">
                Painel Admin · Jogos do Mengão
              </h1>
              <p className="text-xs text-zinc-400">Acesso exclusivo com sua conta do Google</p>
            </div>
          </div>

          <p className="text-sm leading-relaxed text-zinc-300">
            Entre com a conta Google administradora (<span className="font-mono text-xs text-white">{ADMIN_EMAIL}</span>)
            para gerenciar planos, valores, Pix, WhatsApp, gerar chaves de liberação e acompanhar
            quantas pessoas estão usando o aplicativo.
          </p>

          {googleUser && (
            <div className="rounded-lg border border-red-900/60 bg-red-950/50 p-3 text-xs text-red-200 space-y-2">
              <p>
                Conectado como <span className="font-mono">{googleUser.email}</span>, que não possui
                permissão de administrador.
              </p>
              <button
                type="button"
                onClick={() => signOutGoogleAccount()}
                className="underline font-semibold text-white"
              >
                Sair desta conta e escolher outra
              </button>
            </div>
          )}

          {authError && (
            <p className="rounded-lg bg-red-950/70 px-3 py-2 text-xs text-red-300">{authError}</p>
          )}

          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={authLoading}
            className="inline-flex w-full items-center justify-center gap-2.5 rounded-lg bg-[#C8102E] py-3 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50"
          >
            <Lock className="h-4 w-4" />
            {authLoading ? 'Conectando ao Google...' : 'Entrar com conta Google'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-10 space-y-8">
      {/* Cabeçalho do Administrador */}
      <div className="flex flex-col justify-between gap-4 border-b border-zinc-800 pb-6 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3.5">
          <MengaoShield className="h-10 w-10 shrink-0" />
          <div>
            <h1 className="font-display text-3xl font-bold text-white">
              Administração · {settings.appName}
            </h1>
            <p className="text-xs text-zinc-400">
              Conectado via Google: {googleUser?.displayName || 'Administrador'} ({googleUser?.email})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => fetchAdminServerData()}
            className="inline-flex items-center gap-2 rounded-lg border border-zinc-700 bg-zinc-900 px-3.5 py-2 text-xs font-semibold text-zinc-100 hover:bg-zinc-800"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loadingStats ? 'animate-spin' : ''}`} />
            Atualizar uso
          </button>
          <button
            type="button"
            onClick={() => signOutGoogleAccount()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-950 px-3.5 py-2 text-xs font-semibold text-zinc-300 hover:bg-zinc-800"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sair do Admin
          </button>
        </div>
      </div>

      {/* 1. Pessoas usando o aplicativo em tempo real */}
      <section className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-[#C8102E]" />
            <h2 className="font-display text-2xl font-bold text-white">
              Quantas pessoas estão usando seu app
            </h2>
          </div>
          <span className="text-xs text-zinc-400">Atualização automática a cada 15s</span>
        </div>

        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
            <p className="text-xs text-zinc-400">Usando agora (online)</p>
            <p className="mt-2 font-display text-4xl font-extrabold text-emerald-400 tabular-nums">
              {deviceStats.onlineAgora}
            </p>
          </div>
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
            <p className="text-xs text-zinc-400">Aparelhos instalados</p>
            <p className="mt-2 font-display text-4xl font-extrabold text-white tabular-nums">
              {deviceStats.totalInstalados}
            </p>
          </div>
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
            <p className="text-xs text-zinc-400">Licenças ativas</p>
            <p className="mt-2 font-display text-4xl font-extrabold text-white tabular-nums">
              {deviceStats.ativosComLicenca}
            </p>
          </div>
          <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
            <p className="text-xs text-zinc-400">Smart TVs pareadas</p>
            <p className="mt-2 font-display text-4xl font-extrabold text-red-400 tabular-nums">
              {deviceStats.tvsConectadas}
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-zinc-800 bg-zinc-900 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-zinc-800 bg-zinc-950 text-zinc-400">
              <tr>
                <th className="px-5 py-3 font-medium">Código do aparelho</th>
                <th className="px-5 py-3 font-medium">Plataforma / Tipo</th>
                <th className="px-5 py-3 font-medium">Atividade</th>
                <th className="px-5 py-3 font-medium">Licença / Plano</th>
                <th className="px-5 py-3 font-medium">Último sinal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {deviceStats.dispositivos.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-zinc-400">
                    Nenhum aparelho abriu o App ainda. Assim que um cliente instalar e abrir o app
                    Jogos do Mengão, ele aparecerá aqui.
                  </td>
                </tr>
              ) : (
                deviceStats.dispositivos.map((dev) => {
                  const isOnlineNow =
                    Date.now() - new Date(dev.lastSeenAt).getTime() <= 3 * 60 * 1000;
                  return (
                    <tr key={dev.deviceCode} className="hover:bg-zinc-950/60">
                      <td className="px-5 py-3 font-mono font-semibold text-white">
                        {dev.deviceCode}
                      </td>
                      <td className="px-5 py-3 text-zinc-300">
                        {dev.isTv ? 'Smart TV' : 'Celular / PWA'} · {dev.platform}
                      </td>
                      <td className="px-5 py-3">
                        <span
                          className={`font-semibold ${
                            isOnlineNow ? 'text-emerald-400' : 'text-zinc-400'
                          }`}
                        >
                          {dev.isStreaming
                            ? 'Assistindo agora'
                            : isOnlineNow
                              ? 'App aberto agora'
                              : 'Offline'}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-zinc-300">
                        {dev.licenseActive ? `Ativo · ${dev.planName}` : 'Aguardando chave'}
                      </td>
                      <td className="px-5 py-3 font-mono text-zinc-400 tabular-nums">
                        {new Date(dev.lastSeenAt).toLocaleString('pt-BR')}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* 2. Configurações de WhatsApp, Pix e Anti-Retransmissão */}
      <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-6 space-y-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-[#C8102E]" />
          <h2 className="font-display text-2xl font-bold text-white">
            WhatsApp, Pix e Proteção Anti-Retransmissão
          </h2>
        </div>

        <form onSubmit={handleSaveSettings} className="grid grid-cols-1 gap-4 md:grid-cols-12">
          <div className="md:col-span-4">
            <label className="block text-xs font-medium text-zinc-300">Nome do App e Vitrine</label>
            <input
              type="text"
              required
              maxLength={60}
              value={formSettings.appName}
              onChange={(e) => setFormSettings({ ...formSettings, appName: e.target.value })}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-8">
            <label className="block text-xs font-medium text-zinc-300">Frase de destaque na Vitrine</label>
            <input
              type="text"
              required
              maxLength={160}
              value={formSettings.tagline}
              onChange={(e) => setFormSettings({ ...formSettings, tagline: e.target.value })}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-zinc-300">
              Seu WhatsApp (DDI + DDD + número)
            </label>
            <input
              type="tel"
              value={formSettings.whatsappNumber}
              onChange={(e) => setFormSettings({ ...formSettings, whatsappNumber: e.target.value })}
              placeholder="5521999999999"
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-zinc-300">Tipo da Chave Pix</label>
            <select
              value={formSettings.pixType}
              onChange={(e) =>
                setFormSettings({ ...formSettings, pixType: e.target.value as PixType })
              }
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            >
              <option value="CPF">CPF</option>
              <option value="CNPJ">CNPJ</option>
              <option value="E-mail">E-mail</option>
              <option value="Telefone">Telefone</option>
              <option value="Aleatória">Aleatória</option>
            </select>
          </div>

          <div className="md:col-span-4">
            <label className="block text-xs font-medium text-zinc-300">Chave Pix</label>
            <input
              type="text"
              maxLength={140}
              value={formSettings.pixKey}
              onChange={(e) => setFormSettings({ ...formSettings, pixKey: e.target.value })}
              placeholder="Sua chave Pix para recebimento"
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-zinc-300">Nome do recebedor Pix</label>
            <input
              type="text"
              maxLength={80}
              value={formSettings.pixReceiverName}
              onChange={(e) =>
                setFormSettings({ ...formSettings, pixReceiverName: e.target.value })
              }
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-9 flex items-center gap-3 rounded-lg border border-zinc-800 bg-zinc-950 px-4 py-3">
            <input
              id="tvOnlyToggle"
              type="checkbox"
              checked={formSettings.tvOnlyAntiRetransmission}
              onChange={(e) =>
                setFormSettings({
                  ...formSettings,
                  tvOnlyAntiRetransmission: e.target.checked,
                })
              }
              className="h-4 w-4 accent-[#C8102E]"
            />
            <label htmlFor="tvOnlyToggle" className="text-xs text-zinc-200 cursor-pointer">
              <span className="font-semibold text-white">Proteção Anti-Retransmissão:</span>{' '}
              bloquear retransmissão para outros aparelhos e liberar transmissão somente para Smart
              TVs (Android TV e LG webOS).
            </label>
          </div>

          <div className="md:col-span-3 flex items-center">
            <button
              type="submit"
              disabled={savingSettings}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#C8102E] px-4 py-3 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              {savingSettings ? 'Salvando...' : 'Salvar configurações'}
            </button>
          </div>
        </form>

        {settingsMsg && (
          <p className="rounded-lg bg-emerald-950/60 px-3 py-2 text-xs text-emerald-300">
            {settingsMsg}
          </p>
        )}
      </section>

      {/* 3. Gerenciar Planos, Valores e Adicionar Novos Planos */}
      <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-6 space-y-6">
        <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-display text-2xl font-bold text-white">
              Gerenciar Planos e Valores da Vitrine
            </h2>
            <p className="text-xs text-zinc-400">
              Edite preços, nomes e duração ou adicione novos planos instantaneamente.
            </p>
          </div>
          {planFeedback && (
            <span className="text-xs font-semibold text-emerald-400">{planFeedback}</span>
          )}
        </div>

        {/* Lista de planos com edição inline */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className="rounded-xl border border-zinc-800 bg-zinc-950 p-4 flex flex-col justify-between gap-4"
            >
              {editingPlanId === plan.id && planDraft ? (
                <form onSubmit={handleSaveEditedPlan} className="space-y-3">
                  <input
                    type="text"
                    required
                    value={planDraft.name}
                    onChange={(e) => setPlanDraft({ ...planDraft, name: e.target.value })}
                    placeholder="Nome do plano"
                    className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 text-xs font-semibold text-white"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={planDraft.priceText}
                      onChange={(e) => setPlanDraft({ ...planDraft, priceText: e.target.value })}
                      placeholder="Valor (ex: R$ 29,90)"
                      className="rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 font-mono text-xs text-white"
                    />
                    <input
                      type="number"
                      min={0}
                      max={3650}
                      value={planDraft.days}
                      onChange={(e) =>
                        setPlanDraft({ ...planDraft, days: Number(e.target.value) })
                      }
                      placeholder="Dias"
                      className="rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 font-mono text-xs text-white"
                    />
                  </div>
                  <input
                    type="text"
                    value={planDraft.subtitle}
                    onChange={(e) => setPlanDraft({ ...planDraft, subtitle: e.target.value })}
                    placeholder="Descrição curta"
                    className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 text-xs text-white"
                  />
                  <textarea
                    rows={3}
                    value={planFeaturesText}
                    onChange={(e) => setPlanFeaturesText(e.target.value)}
                    placeholder="Benefícios (1 por linha)"
                    className="w-full rounded-md border border-zinc-700 bg-zinc-900 px-2.5 py-1.5 text-xs text-white"
                  />
                  <div className="flex items-center gap-4 text-xs text-zinc-300">
                    <label className="flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={planDraft.active}
                        onChange={(e) => setPlanDraft({ ...planDraft, active: e.target.checked })}
                      />
                      Visível na vitrine
                    </label>
                    <label className="flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={planDraft.featured}
                        onChange={(e) =>
                          setPlanDraft({ ...planDraft, featured: e.target.checked })
                        }
                      />
                      Destaque
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={savingPlan}
                      className="flex-1 rounded-md bg-[#C8102E] py-1.5 text-xs font-semibold text-white hover:bg-red-700"
                    >
                      Salvar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingPlanId(null);
                        setPlanDraft(null);
                      }}
                      className="rounded-md border border-zinc-700 px-3 py-1.5 text-xs text-zinc-300"
                    >
                      Cancelar
                    </button>
                  </div>
                </form>
              ) : (
                <>
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-zinc-400">
                      <span>{plan.active ? 'Ativo na vitrine' : 'Oculto'}</span>
                      <span className="font-mono tabular-nums">{plan.days}d</span>
                    </div>
                    <h3 className="mt-1 font-display text-xl font-bold text-white">{plan.name}</h3>
                    <p className="font-mono text-lg font-bold text-red-400 tabular-nums">
                      {plan.priceText}
                    </p>
                    <p className="mt-1 text-xs text-zinc-400">{plan.subtitle}</p>
                  </div>
                  <div className="flex items-center gap-2 border-t border-zinc-800 pt-3">
                    <button
                      type="button"
                      onClick={() => startEditingPlan(plan)}
                      className="flex-1 rounded-md border border-zinc-700 bg-zinc-900 py-1.5 text-xs font-semibold text-white hover:bg-zinc-800"
                    >
                      Editar valor / texto
                    </button>
                    <button
                      type="button"
                      disabled={savingPlan}
                      onClick={() => handleDeletePlan(plan.id, plan.name)}
                      className="rounded-md border border-red-900/60 bg-red-950/40 p-1.5 text-red-400 hover:bg-red-950"
                      aria-label={`Excluir plano ${plan.name}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        {/* Adicionar Novo Plano */}
        <form
          onSubmit={handleCreateNewPlan}
          className="rounded-xl border border-zinc-800 bg-zinc-950 p-5 space-y-4"
        >
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Plus className="h-4 w-4 text-[#C8102E]" />
            <span>Adicionar novo plano na vitrine</span>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
            <div className="md:col-span-3">
              <input
                type="text"
                required
                value={newPlanName}
                onChange={(e) => setNewPlanName(e.target.value)}
                placeholder="Nome (ex: Plano Libertadores)"
                className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-white focus:border-[#C8102E] focus:outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <input
                type="text"
                required
                value={newPlanPrice}
                onChange={(e) => setNewPlanPrice(e.target.value)}
                placeholder="Valor (ex: R$ 49,90)"
                className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <input
                type="number"
                min={0}
                max={3650}
                value={newPlanDays}
                onChange={(e) => setNewPlanDays(Number(e.target.value))}
                placeholder="Dias"
                className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
              />
            </div>
            <div className="md:col-span-3">
              <input
                type="text"
                value={newPlanSubtitle}
                onChange={(e) => setNewPlanSubtitle(e.target.value)}
                placeholder="Descrição curta"
                className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-white focus:border-[#C8102E] focus:outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={savingPlan}
                className="w-full rounded-lg bg-[#C8102E] px-3 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50"
              >
                Adicionar plano
              </button>
            </div>
          </div>
          <input
            type="text"
            value={newPlanFeatures}
            onChange={(e) => setNewPlanFeatures(e.target.value)}
            placeholder="Benefício principal (opcional)"
            className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-white focus:border-[#C8102E] focus:outline-none"
          />
        </form>
      </section>

      {/* 4. Gerador de Chave Offline por Código do Celular / TV */}
      <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-6 space-y-5">
        <div className="flex items-center gap-2">
          <KeyRound className="h-5 w-5 text-[#C8102E]" />
          <h2 className="font-display text-2xl font-bold text-white">
            Gerar Chave de Liberação por Código do Aparelho
          </h2>
        </div>

        <form onSubmit={handleGenerateOfflineKey} className="grid grid-cols-1 gap-4 md:grid-cols-12 md:items-end">
          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-zinc-300">
              Código do aparelho (WhatsApp)
            </label>
            <input
              type="text"
              required
              value={deviceCodeInput}
              onChange={(e) => setDeviceCodeInput(e.target.value.toUpperCase())}
              placeholder="TC-A1B2-C3D4"
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm uppercase text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-zinc-300">Duração</label>
            <select
              value={offlineDays}
              onChange={(e) => handleDaysPresetChange(Number(e.target.value))}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            >
              <option value={30}>1 mês (30 dias)</option>
              <option value={90}>3 meses (90 dias)</option>
              <option value={180}>6 meses (180 dias)</option>
              <option value={365}>1 ano (365 dias)</option>
              <option value={0}>Outros (escolher data)</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-zinc-300">Data de validade</label>
            <input
              type="date"
              required
              value={validadeDate}
              onChange={(e) => setValidadeDate(e.target.value)}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-zinc-300">Plano</label>
            <select
              value={offlinePlan}
              onChange={(e) => handleOfflinePlanSelect(e.target.value)}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-white focus:border-[#C8102E] focus:outline-none"
            >
              {plans.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
              {!plans.some((p) => p.name === 'Outros') && <option value="Outros">Outros</option>}
            </select>
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              disabled={generatingKey}
              className="w-full rounded-lg bg-[#C8102E] px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50 whitespace-nowrap"
            >
              {generatingKey ? 'Gerando...' : 'Gerar chave'}
            </button>
          </div>
        </form>

        {offlineError && (
          <p className="rounded-lg bg-red-950/70 px-3 py-2 text-xs text-red-300">{offlineError}</p>
        )}

        {generatedKey && (
          <div className="rounded-lg border border-emerald-800 bg-emerald-950/50 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-emerald-200">
                Chave gerada para {generatedKey.deviceCode} · {generatedKey.plano} · vence em{' '}
                {formatDatePtBr(generatedKey.expira_em)} ({generatedKey.dias}d)
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(generatedKey.activationKey);
                    setCopiedGenerated(true);
                    window.setTimeout(() => setCopiedGenerated(false), 1800);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-md border border-emerald-700 bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-emerald-200 hover:bg-zinc-800"
                >
                  {copiedGenerated ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      Copiada
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      Copiar chave
                    </>
                  )}
                </button>
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(
                    `Sua assinatura ${settings.appName} (${generatedKey.plano}) foi liberada até ${formatDatePtBr(
                      generatedKey.expira_em
                    )} para o aparelho ${generatedKey.deviceCode}.\n\nCole esta chave no aplicativo:\n${generatedKey.activationKey}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-md bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-600"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  Enviar no WhatsApp
                </a>
              </div>
            </div>
            <p className="break-all font-mono text-xs text-emerald-100">
              {generatedKey.activationKey}
            </p>
          </div>
        )}

        {offlineKeys.length > 0 && (
          <div className="overflow-x-auto border-t border-zinc-800 pt-4">
            <p className="mb-3 flex items-center gap-2 text-xs font-semibold text-zinc-400">
              <Tv className="h-3.5 w-3.5" />
              Últimas chaves offline emitidas
            </p>
            <table className="w-full text-left text-xs">
              <thead className="border-b border-zinc-800 text-zinc-400">
                <tr>
                  <th className="py-2 pr-4 font-medium">Aparelho</th>
                  <th className="py-2 pr-4 font-medium">Plano</th>
                  <th className="py-2 pr-4 font-medium">Dias</th>
                  <th className="py-2 pr-4 font-medium">Validade</th>
                  <th className="py-2 font-medium">Chave</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800">
                {offlineKeys.slice(0, 8).map((item) => (
                  <tr key={item.id}>
                    <td className="py-2 pr-4 font-mono font-semibold text-white">
                      {item.deviceCode}
                    </td>
                    <td className="py-2 pr-4 text-zinc-300">{item.plano}</td>
                    <td className="py-2 pr-4 font-mono tabular-nums text-zinc-300">
                      {item.dias}d
                    </td>
                    <td className="py-2 pr-4 font-mono tabular-nums text-zinc-400">
                      {formatDatePtBr(item.expira_em)}
                    </td>
                    <td className="py-2 font-mono text-[11px] text-zinc-500 truncate max-w-[240px]">
                      {item.activationKey}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
