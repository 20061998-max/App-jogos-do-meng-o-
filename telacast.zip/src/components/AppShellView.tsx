import { useEffect, useRef, useState } from 'react';
import {
  Check,
  Copy,
  KeyRound,
  Lock,
  Maximize2,
  MessageCircle,
  Minimize2,
  Play,
  QrCode,
  ShieldCheck,
  Square,
  Tv,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  buildWhatsappSendCodeHref,
  getSavedOfflineLicenseState,
  OfflineLicenseState,
  reportDeviceHeartbeat,
  verifyAndSaveOfflineKey,
} from '../lib/offlineLicense';
import { AppSettingsDoc, PlanItem } from '../lib/storeCatalog';
import { formatDatePtBr } from '../types';
import { MengaoShield } from './MengaoShield';
import { SubscriberView } from './SubscriberView';

interface AppShellViewProps {
  settings: AppSettingsDoc;
  plans: PlanItem[];
}

export function AppShellView({ settings, plans }: AppShellViewProps) {
  const { detectedPlatform, isAndroidTV, isWebOS } = usePWAInstall();
  const isTvDevice = isAndroidTV || isWebOS;
  const activePlans = plans.filter((p) => p.active);

  const [appTab, setAppTab] = useState<'player' | 'conta'>('player');
  const [hostAddress, setHostAddress] = useState('http://192.168.1.50:8080');
  const [streamToken, setStreamToken] = useState('');
  const [streamMode, setStreamMode] = useState<'idle' | 'live' | 'error'>('idle');
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [offlineLicense, setOfflineLicense] = useState<OfflineLicenseState | null>(null);
  const [selectedRenewalPlan, setSelectedRenewalPlan] = useState<string>(
    activePlans[0]?.name || '1 Mês'
  );
  const [customValidity, setCustomValidity] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [keyError, setKeyError] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);

  const stageRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const streamModeRef = useRef<'idle' | 'live' | 'error'>('idle');
  streamModeRef.current = streamMode;

  useEffect(() => {
    const refreshLicense = () => {
      getSavedOfflineLicenseState().then((state) => {
        setOfflineLicense(state);
        if (!state.ativo) {
          abortRef.current?.abort();
          setStreamMode('idle');
        }
        void reportDeviceHeartbeat({
          deviceCode: state.deviceCode,
          platform: detectedPlatform,
          isTv: isTvDevice,
          licenseActive: state.ativo,
          planName: state.plano,
          isStreaming: streamModeRef.current === 'live',
        });
      });
    };

    refreshLicense();

    const intervalId = window.setInterval(refreshLicense, 30000);
    window.addEventListener('focus', refreshLicense);
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => {
      window.clearInterval(intervalId);
      window.removeEventListener('focus', refreshLicense);
      document.removeEventListener('fullscreenchange', onFsChange);
      abortRef.current?.abort();
    };
  }, [detectedPlatform, isTvDevice]);

  const isAppUnlocked = Boolean(offlineLicense?.ativo);
  const chosenPlan = activePlans.find((p) => p.name === selectedRenewalPlan) || activePlans[0];
  const retransmissionBlockedForNonTv = settings.tvOnlyAntiRetransmission && !isTvDevice;

  async function handleOfflineUnlock(e: React.FormEvent) {
    e.preventDefault();
    setKeyError(null);
    const result = await verifyAndSaveOfflineKey(keyInput);
    setOfflineLicense(result);
    if (result.ativo) {
      setKeyInput('');
      void reportDeviceHeartbeat({
        deviceCode: result.deviceCode,
        platform: detectedPlatform,
        isTv: isTvDevice,
        licenseActive: true,
        planName: result.plano,
        isStreaming: false,
      });
    } else {
      setKeyError(result.motivo || 'Chave inválida para este aparelho.');
    }
  }

  async function toggleFullscreenGameMode() {
    if (!document.fullscreenElement) {
      await stageRef.current?.requestFullscreen?.();
      try {
        const orientation = screen.orientation as unknown as {
          lock?: (mode: string) => Promise<void>;
        };
        await orientation?.lock?.('landscape');
      } catch {
        // Ignorado em dispositivos desktop
      }
    } else {
      await document.exitFullscreen?.();
    }
  }

  async function connectToHostStream() {
    abortRef.current?.abort();
    setStreamError(null);

    if (retransmissionBlockedForNonTv) {
      setStreamMode('error');
      setStreamError(
        'Proteção Anti-Retransmissão ativa: a retransmissão entre aparelhos é permitida apenas para Smart TVs (Android TV ou LG webOS).'
      );
      return;
    }

    const cleanHost = hostAddress.trim().replace(/\/$/, '');
    const cleanToken = streamToken.trim();
    if (!cleanHost || !cleanToken) {
      setStreamError('Informe o IP local do aparelho transmissor e o token da sessão.');
      setStreamMode('error');
      return;
    }

    const controller = new AbortController();
    abortRef.current = controller;
    setStreamMode('live');

    if (offlineLicense?.deviceCode) {
      void reportDeviceHeartbeat({
        deviceCode: offlineLicense.deviceCode,
        platform: detectedPlatform,
        isTv: isTvDevice,
        licenseActive: Boolean(offlineLicense.ativo),
        planName: offlineLicense.plano,
        isStreaming: true,
      });
    }

    try {
      const url = `${cleanHost}/stream?token=${encodeURIComponent(cleanToken)}`;
      const res = await fetch(url, {
        headers: {
          'X-TelaCast-App': isWebOS ? 'TelaCast-LG-webOS/1.0' : 'TelaCast-TV-App/1.0',
          'X-Device-Type': isTvDevice ? 'tv' : 'mobile',
        },
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        setStreamMode('error');
        setStreamError(
          `Conexão recusada (HTTP ${res.status}). Verifique o IP, o token e se este aparelho é uma TV autorizada.`
        );
        return;
      }

      const reader = res.body.getReader();
      let buffer = new Uint8Array(0);

      while (!controller.signal.aborted) {
        const { value, done } = await reader.read();
        if (done) break;
        if (!value) continue;

        const merged = new Uint8Array(buffer.length + value.length);
        merged.set(buffer);
        merged.set(value, buffer.length);
        buffer = merged;

        let start = -1;
        for (let i = 0; i < buffer.length - 1; i += 1) {
          if (buffer[i] === 0xff && buffer[i + 1] === 0xd8) {
            start = i;
            break;
          }
        }
        if (start === -1) continue;

        let end = -1;
        for (let i = start + 2; i < buffer.length - 1; i += 1) {
          if (buffer[i] === 0xff && buffer[i + 1] === 0xd9) {
            end = i + 2;
            break;
          }
        }
        if (end === -1) continue;

        const jpegSlice = buffer.slice(start, end);
        buffer = buffer.slice(end);

        const blob = new Blob([jpegSlice], { type: 'image/jpeg' });
        const bitmap = await createImageBitmap(blob);
        const canvas = canvasRef.current;
        if (canvas) {
          if (canvas.width !== bitmap.width || canvas.height !== bitmap.height) {
            canvas.width = bitmap.width;
            canvas.height = bitmap.height;
          }
          canvas.getContext('2d')?.drawImage(bitmap, 0, 0);
        }
        bitmap.close();
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        setStreamMode('error');
        setStreamError('Não foi possível conectar ao transmissor na rede Wi-Fi.');
      }
    }
  }

  function disconnectStream() {
    abortRef.current?.abort();
    setStreamMode('idle');
    setStreamError(null);
  }

  return (
    <div
      className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100 select-none"
      onContextMenu={(e) => e.preventDefault()}
    >
      <header className="border-b border-zinc-800 bg-zinc-900">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-5 py-3">
          <div className="flex items-center gap-2.5 shrink-0">
            <MengaoShield className="h-7 w-7 shrink-0" />
            <span className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap">
              {settings.appName} App
            </span>
          </div>

          <nav className="flex items-center gap-5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setAppTab('player')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                appTab === 'player'
                  ? 'border-[#C8102E] text-white'
                  : 'border-transparent text-zinc-400 hover:text-white'
              }`}
            >
              Assistir jogos
            </button>
            <button
              type="button"
              onClick={() => setAppTab('conta')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                appTab === 'conta'
                  ? 'border-[#C8102E] text-white'
                  : 'border-transparent text-zinc-400 hover:text-white'
              }`}
            >
              Planos e Chave
            </button>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            {offlineLicense?.ativo && (
              <span className="hidden sm:inline font-mono text-xs text-emerald-400 tabular-nums">
                {offlineLicense.dias_restantes}d restantes
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {appTab === 'conta' ? (
          <SubscriberView settings={settings} plans={plans} />
        ) : !isAppUnlocked ? (
          <div className="mx-auto max-w-lg px-6 py-10">
            <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-7 space-y-5">
              <div className="flex items-center gap-3">
                <MengaoShield className="h-9 w-9 shrink-0" />
                <div>
                  <h1 className="font-display text-xl font-bold text-white">
                    Ativação Offline · {settings.appName}
                  </h1>
                  <p className="text-xs text-zinc-400">
                    Liberação exclusiva vinculada a este aparelho
                  </p>
                </div>
              </div>

              <p className="text-sm text-zinc-300">
                {offlineLicense?.expira_em
                  ? `Sua assinatura venceu em ${formatDatePtBr(offlineLicense.expira_em)}. Escolha o plano, pague via Pix ou WhatsApp e cole a nova chave.`
                  : 'Este aparelho possui um código único que impede repasse a terceiros. Escolha o plano desejado, faça o Pix ou combine no WhatsApp e cole a chave recebida.'}
              </p>

              <div className="space-y-2.5">
                <p className="text-xs font-medium text-zinc-300">
                  Escolha o plano desejado
                </p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {activePlans.map((plan) => (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => setSelectedRenewalPlan(plan.name)}
                      className={`rounded-lg border px-2.5 py-2 text-left text-xs transition-colors ${
                        selectedRenewalPlan === plan.name
                          ? 'border-[#C8102E] bg-[#C8102E]/20 text-white'
                          : 'border-zinc-700 bg-zinc-950 text-zinc-300 hover:border-zinc-500'
                      }`}
                    >
                      <div className="font-semibold">{plan.name}</div>
                      <div className="font-mono text-[11px] text-zinc-300 tabular-nums">
                        {plan.priceText}
                      </div>
                    </button>
                  ))}
                </div>

                {selectedRenewalPlan === 'Outros' && (
                  <div className="pt-1">
                    <label className="block text-[11px] font-medium text-zinc-300">
                      Qual validade você deseja? (ex: 15 dias, 2 meses ou até 20/01/2027)
                    </label>
                    <input
                      type="text"
                      value={customValidity}
                      onChange={(e) => setCustomValidity(e.target.value)}
                      placeholder="Ex: 45 dias ou até 20/01/2027"
                      className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-xs text-white focus:border-[#C8102E] focus:outline-none"
                    />
                  </div>
                )}
              </div>

              {settings.pixKey && (
                <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-3.5 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                      <QrCode className="h-3.5 w-3.5 text-[#C8102E]" />
                      Pix ({settings.pixType}) · {settings.pixReceiverName}
                    </p>
                    <p className="font-mono text-xs text-white truncate">{settings.pixKey}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(settings.pixKey);
                      setCopiedPix(true);
                      window.setTimeout(() => setCopiedPix(false), 1800);
                    }}
                    className="rounded-md border border-zinc-700 bg-zinc-800 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-zinc-700 shrink-0"
                  >
                    {copiedPix ? 'Copiado' : 'Copiar Pix'}
                  </button>
                </div>
              )}

              <div className="rounded-lg border border-zinc-700 bg-zinc-950 p-4 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[11px] text-zinc-400">Código único deste aparelho</p>
                    <p className="mt-1 font-mono text-lg font-bold text-white tabular-nums">
                      {offlineLicense?.deviceCode || 'Gerando...'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!offlineLicense?.deviceCode) return;
                      navigator.clipboard?.writeText(offlineLicense.deviceCode);
                      setCopiedCode(true);
                      window.setTimeout(() => setCopiedCode(false), 1800);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-2 text-xs font-semibold text-white hover:bg-zinc-700"
                  >
                    {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedCode ? 'Copiado' : 'Copiar'}
                  </button>
                </div>

                {offlineLicense?.deviceCode && (
                  <a
                    href={buildWhatsappSendCodeHref(
                      offlineLicense.deviceCode,
                      settings.whatsappNumber,
                      Boolean(offlineLicense.expira_em),
                      selectedRenewalPlan,
                      customValidity,
                      chosenPlan?.priceText
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-700 py-2.5 text-xs font-semibold text-white hover:bg-emerald-600"
                  >
                    <MessageCircle className="h-4 w-4" />
                    {offlineLicense.expira_em
                      ? `Renovar (${selectedRenewalPlan}) no WhatsApp`
                      : `Enviar código (${selectedRenewalPlan}) no WhatsApp`}
                  </a>
                )}
              </div>

              <form onSubmit={handleOfflineUnlock} className="space-y-3">
                <label className="block text-xs font-medium text-zinc-300">
                  Chave de liberação
                </label>
                <textarea
                  required
                  rows={3}
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  placeholder="Cole a chave TC1... recebida"
                  className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
                />
                {keyError && (
                  <p className="rounded-lg bg-red-950/80 px-3 py-2 text-xs text-red-300">
                    {keyError}
                  </p>
                )}
                <button
                  type="submit"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#C8102E] py-2.5 text-sm font-semibold text-white hover:bg-red-700"
                >
                  <KeyRound className="h-4 w-4" />
                  Liberar aplicativo offline
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="mx-auto max-w-6xl px-5 py-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-400">
              <span>
                Licença ativa ({offlineLicense?.plano}) · Válida até{' '}
                {formatDatePtBr(offlineLicense?.expira_em || null)}
              </span>
              <span className="flex items-center gap-2 font-mono">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                {isTvDevice ? 'Smart TV Autorizada' : 'Proteção Anti-Retransmissão Ativa'} ·{' '}
                {offlineLicense?.deviceCode}
              </span>
            </div>

            {retransmissionBlockedForNonTv && (
              <div className="rounded-xl border border-amber-700/60 bg-amber-950/40 p-4 flex items-start gap-3 text-xs text-amber-200">
                <Lock className="h-4 w-4 shrink-0 mt-0.5 text-amber-400" />
                <div>
                  <p className="font-semibold text-white">
                    Proteção Anti-Retransmissão: Somente para Smart TVs
                  </p>
                  <p className="mt-1 leading-relaxed text-amber-200/90">
                    A retransmissão entre dispositivos está bloqueada neste celular/PC. Para
                    retransmitir ou receber o jogo espelhado na rede, abra o aplicativo Jogos do
                    Mengão diretamente em uma Smart TV (Android TV ou LG webOS).
                  </p>
                </div>
              </div>
            )}

            <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-4 grid grid-cols-1 gap-3 md:grid-cols-12 md:items-end">
              <div className="md:col-span-5">
                <label className="block text-xs font-medium text-zinc-400">
                  IP do transmissor
                </label>
                <input
                  type="url"
                  value={hostAddress}
                  onChange={(e) => setHostAddress(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
                />
              </div>

              <div className="md:col-span-3">
                <label className="block text-xs font-medium text-zinc-400">
                  Token da sessão
                </label>
                <input
                  type="text"
                  value={streamToken}
                  onChange={(e) => setStreamToken(e.target.value)}
                  placeholder="TC-8F4A21"
                  className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
                />
              </div>

              <div className="md:col-span-4 flex items-center gap-2">
                <button
                  type="button"
                  onClick={streamMode === 'live' ? disconnectStream : connectToHostStream}
                  className={`flex-1 inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                    streamMode === 'live'
                      ? 'bg-zinc-700 text-white hover:bg-zinc-600'
                      : 'bg-[#C8102E] text-white hover:bg-red-700'
                  }`}
                >
                  {streamMode === 'live' ? (
                    <>
                      <Square className="h-3.5 w-3.5" />
                      Parar
                    </>
                  ) : (
                    <>
                      <Play className="h-3.5 w-3.5" />
                      Assistir jogo na TV
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={toggleFullscreenGameMode}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-xs font-semibold text-zinc-200 hover:bg-zinc-800 whitespace-nowrap"
                >
                  {isFullscreen ? (
                    <>
                      <Minimize2 className="h-3.5 w-3.5" />
                      Sair
                    </>
                  ) : (
                    <>
                      <Maximize2 className="h-3.5 w-3.5" />
                      Tela cheia
                    </>
                  )}
                </button>
              </div>
            </div>

            {streamError && (
              <p className="rounded-lg border border-red-900/60 bg-red-950/60 px-4 py-2.5 text-xs text-red-300">
                {streamError}
              </p>
            )}

            <div
              ref={stageRef}
              className="relative flex min-h-[65vh] items-center justify-center overflow-hidden rounded-xl border border-zinc-800 bg-black"
            >
              {streamMode === 'live' ? (
                <>
                  <canvas ref={canvasRef} className="max-h-full max-w-full object-contain" />
                  <div className="pointer-events-none absolute bottom-3 right-4 font-mono text-[11px] text-white/35">
                    {settings.appName} · {offlineLicense?.deviceCode}
                  </div>
                </>
              ) : (
                <div className="p-8 text-center space-y-3">
                  <Tv className="mx-auto h-10 w-10 text-[#C8102E]" />
                  <p className="font-display text-xl font-bold text-white">
                    {settings.appName} pronto para transmitir na Smart TV
                  </p>
                  <p className="max-w-md text-xs text-zinc-400">
                    Para proteger contra pirataria, a recepção de retransmissão funciona apenas em
                    Smart TVs (Android TV e LG webOS) com token da sessão.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
