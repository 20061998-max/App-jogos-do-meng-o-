import { useEffect, useState } from 'react';
import {
  Check,
  Copy,
  KeyRound,
  MessageCircle,
  QrCode,
  ShieldCheck,
} from 'lucide-react';
import {
  buildWhatsappSendCodeHref,
  getSavedOfflineLicenseState,
  OfflineLicenseState,
  verifyAndSaveOfflineKey,
} from '../lib/offlineLicense';
import { AppSettingsDoc, PlanItem } from '../lib/storeCatalog';
import { formatDatePtBr } from '../types';
import { MengaoShield } from './MengaoShield';

interface SubscriberViewProps {
  settings: AppSettingsDoc;
  plans: PlanItem[];
  preselectedPlan?: string;
}

export function SubscriberView({
  settings,
  plans,
  preselectedPlan,
}: SubscriberViewProps) {
  const activePlans = plans.filter((p) => p.active);
  const [offlineState, setOfflineState] = useState<OfflineLicenseState | null>(null);
  const [selectedPlanName, setSelectedPlanName] = useState<string>(
    preselectedPlan || activePlans[0]?.name || '1 Mês'
  );
  const [customValidity, setCustomValidity] = useState('');
  const [activationInput, setActivationInput] = useState('');
  const [offlineFeedback, setOfflineFeedback] = useState<string | null>(null);
  const [copiedDeviceCode, setCopiedDeviceCode] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);

  useEffect(() => {
    if (preselectedPlan) {
      setSelectedPlanName(preselectedPlan);
    }
  }, [preselectedPlan]);

  useEffect(() => {
    const syncState = () => {
      getSavedOfflineLicenseState().then(setOfflineState);
    };
    syncState();
    window.addEventListener('focus', syncState);
    return () => window.removeEventListener('focus', syncState);
  }, []);

  const chosenPlan = activePlans.find((p) => p.name === selectedPlanName) || activePlans[0];

  async function handleActivateOffline(e: React.FormEvent) {
    e.preventDefault();
    setOfflineFeedback(null);
    const result = await verifyAndSaveOfflineKey(activationInput);
    setOfflineState(result);
    if (result.ativo) {
      setActivationInput('');
      setOfflineFeedback(
        `Acesso liberado no aparelho (${result.plano}) · válido por ${result.dias_restantes} dias.`
      );
    } else {
      setOfflineFeedback(result.motivo || 'Chave de liberação inválida para este aparelho.');
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-7 sm:p-8 space-y-6">
        <div className="flex items-start gap-3.5">
          <MengaoShield className="h-10 w-10 shrink-0" />
          <div>
            <h1 className="font-display text-2xl font-bold text-white">
              Ativação e Pagamento · {settings.appName}
            </h1>
            <p className="mt-1 text-sm text-zinc-300">
              Escolha seu plano, pague via Pix ou WhatsApp enviando o código do seu aparelho e cole a
              chave de liberação recebida.
            </p>
          </div>
        </div>

        {/* Seleção de Planos Dinâmicos */}
        <div className="space-y-2.5">
          <p className="text-xs font-medium text-zinc-300">
            Selecione o plano desejado (valores definidos pelo administrador)
          </p>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
            {activePlans.map((plan) => (
              <button
                key={plan.id}
                type="button"
                onClick={() => setSelectedPlanName(plan.name)}
                className={`rounded-lg border p-3 text-left transition-colors ${
                  selectedPlanName === plan.name
                    ? 'border-[#C8102E] bg-[#C8102E]/15 text-white'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <div className="text-xs font-semibold">{plan.name}</div>
                <div className="mt-1 font-mono text-sm font-bold text-white tabular-nums">
                  {plan.priceText}
                </div>
              </button>
            ))}
          </div>

          {selectedPlanName === 'Outros' && (
            <div className="pt-1">
              <label className="block text-xs font-medium text-zinc-300">
                Informe a validade desejada (ex: 15 dias, 2 meses ou até 20/01/2027)
              </label>
              <input
                type="text"
                value={customValidity}
                onChange={(e) => setCustomValidity(e.target.value)}
                placeholder="Ex: 45 dias ou até 20/01/2027"
                className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-xs text-white focus:border-[#C8102E] focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* Dados Pix do Admin */}
        {settings.pixKey && (
          <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <p className="flex items-center gap-1.5 text-xs font-semibold text-zinc-300">
                <QrCode className="h-3.5 w-3.5 text-[#C8102E]" />
                Chave Pix ({settings.pixType}) · {settings.pixReceiverName}
              </p>
              <p className="font-mono text-xs text-white break-all">{settings.pixKey}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard?.writeText(settings.pixKey);
                setCopiedPix(true);
                window.setTimeout(() => setCopiedPix(false), 1800);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-100 hover:bg-zinc-800 whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              {copiedPix ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              {copiedPix ? 'Pix copiado' : 'Copiar Pix'}
            </button>
          </div>
        )}

        {/* Código Único do Aparelho + WhatsApp */}
        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4 space-y-3">
          <div className="flex items-center justify-between gap-2 text-xs text-zinc-400">
            <span>Código exclusivo deste aparelho (bloqueado se repassado)</span>
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
          </div>
          <div className="flex items-center justify-between gap-3">
            <code className="font-mono text-lg font-bold text-white tabular-nums">
              {offlineState?.deviceCode || 'Gerando...'}
            </code>
            <button
              type="button"
              disabled={!offlineState?.deviceCode}
              onClick={() => {
                if (!offlineState?.deviceCode) return;
                navigator.clipboard?.writeText(offlineState.deviceCode);
                setCopiedDeviceCode(true);
                window.setTimeout(() => setCopiedDeviceCode(false), 1800);
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-100 hover:bg-zinc-800"
            >
              {copiedDeviceCode ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  Copiado
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copiar código
                </>
              )}
            </button>
          </div>

          {offlineState?.deviceCode && (
            <a
              href={buildWhatsappSendCodeHref(
                offlineState.deviceCode,
                settings.whatsappNumber,
                Boolean(offlineState.expira_em),
                selectedPlanName,
                customValidity,
                chosenPlan?.priceText
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-700 py-2.5 text-xs font-semibold text-white hover:bg-emerald-600"
            >
              <MessageCircle className="h-4 w-4" />
              {offlineState.expira_em
                ? `Renovar (${selectedPlanName}) no WhatsApp`
                : `Enviar código (${selectedPlanName} · ${chosenPlan?.priceText || 'Sob consulta'}) no WhatsApp`}
            </a>
          )}
        </div>

        {offlineState?.ativo && (
          <div className="rounded-lg border border-emerald-800 bg-emerald-950/60 p-4 text-xs text-emerald-200 space-y-1">
            <p className="font-semibold">
              Assinatura ativa neste aparelho · {offlineState.plano}
            </p>
            <p className="font-mono tabular-nums">
              Válida até {formatDatePtBr(offlineState.expira_em)} ({offlineState.dias_restantes} dias
              restantes)
            </p>
          </div>
        )}

        {/* Ativação com a chave recebida */}
        <form onSubmit={handleActivateOffline} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-zinc-300">
              Chave de liberação recebida no WhatsApp
            </label>
            <textarea
              required
              rows={3}
              value={activationInput}
              onChange={(e) => setActivationInput(e.target.value)}
              placeholder="Cole aqui a chave TC1... gerada pelo administrador para este aparelho"
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-xs text-white focus:border-[#C8102E] focus:outline-none"
            />
          </div>

          {offlineFeedback && (
            <p
              className={`rounded-lg px-3 py-2 text-xs ${
                offlineState?.ativo
                  ? 'bg-emerald-950/80 text-emerald-300'
                  : 'bg-red-950/80 text-red-300'
              }`}
            >
              {offlineFeedback}
            </p>
          )}

          <button
            type="submit"
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#C8102E] py-2.5 text-sm font-semibold text-white hover:bg-red-700"
          >
            <KeyRound className="h-4 w-4" />
            Validar e liberar acesso offline
          </button>
        </form>
      </div>
    </div>
  );
}
