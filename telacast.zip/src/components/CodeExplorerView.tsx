import { useEffect, useState } from 'react';
import { Check, Copy, Download, FileCode2, Folder } from 'lucide-react';

export function CodeExplorerView() {
  const [files, setFiles] = useState<string[]>([]);
  const [filterScope, setFilterScope] = useState<'all' | 'web' | 'android' | 'webos'>('all');
  const [selectedPath, setSelectedPath] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [loadingFile, setLoadingFile] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/projeto/arvore')
      .then((res) => res.json())
      .then((data) => {
        const list = (data.files ?? []) as string[];
        setFiles(list);
        if (list.length > 0) {
          const defaultFile =
            list.find((f) => f.endsWith('schema.sql')) ??
            list.find((f) => f.endsWith('ScreenMirrorService.kt')) ??
            list[0];
          loadFile(defaultFile);
        }
      });
  }, []);

  async function loadFile(filePath: string) {
    setSelectedPath(filePath);
    setLoadingFile(true);
    try {
      const res = await fetch(`/api/projeto/arquivo?path=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      setContent(data.content ?? '');
    } finally {
      setLoadingFile(false);
    }
  }

  function handleCopy() {
    navigator.clipboard?.writeText(content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  }

  const visibleFiles = files.filter((f) =>
    filterScope === 'all' ? true : f.startsWith(`${filterScope}/`)
  );

  return (
    <div className="mx-auto max-w-6xl px-6 py-10 space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-3xl font-extrabold uppercase tracking-tight text-white">
            Código-fonte do projeto (/web, /android e /webos)
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Inspecione os arquivos reais de React + Firebase, Android / Android TV Kotlin e
            LG webOS TV do Jogos do Mengão no repositório.
          </p>
        </div>

        <a
          href="/api/download-projeto"
          className="inline-flex items-center gap-2 rounded-lg bg-[#C8102E] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#A60D26] transition-colors whitespace-nowrap shrink-0 self-start"
        >
          <Download className="h-4 w-4" />
          Baixar ZIP completo
        </a>
      </div>

      <div className="grid grid-cols-1 overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900 lg:grid-cols-12">
        <aside className="border-b border-zinc-800 bg-zinc-950/60 lg:col-span-4 lg:border-b-0 lg:border-r">
          <div className="flex flex-wrap items-center gap-1 border-b border-zinc-800 p-3">
            {(['all', 'web', 'android', 'webos'] as const).map((scope) => (
              <button
                key={scope}
                type="button"
                onClick={() => setFilterScope(scope)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  filterScope === scope
                    ? 'bg-[#C8102E] text-white'
                    : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'
                }`}
              >
                {scope === 'all' ? 'Todos' : `/${scope}`}
              </button>
            ))}
          </div>

          <div className="max-h-[540px] overflow-y-auto p-2 space-y-0.5">
            {visibleFiles.map((filePath) => {
              const active = filePath === selectedPath;
              return (
                <button
                  key={filePath}
                  type="button"
                  onClick={() => loadFile(filePath)}
                  className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs transition-colors ${
                    active
                      ? 'bg-red-950/50 font-semibold text-red-300 border border-red-900/60'
                      : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'
                  }`}
                >
                  {filePath.startsWith('web/') ? (
                    <Folder className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                  ) : (
                    <FileCode2 className="h-3.5 w-3.5 shrink-0 text-zinc-500" />
                  )}
                  <span className="truncate font-mono">{filePath}</span>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="lg:col-span-8 flex flex-col bg-zinc-950">
          <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900/70 px-4 py-3">
            <span className="truncate font-mono text-xs font-medium text-zinc-300">
              {selectedPath || 'Selecione um arquivo'}
            </span>
            <button
              type="button"
              onClick={handleCopy}
              disabled={!content}
              className="inline-flex items-center gap-1.5 rounded-md border border-zinc-700 bg-zinc-900 px-3 py-1.5 text-xs font-medium text-zinc-200 hover:bg-zinc-800 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  Copiado
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copiar código
                </>
              )}
            </button>
          </div>

          <div className="max-h-[540px] overflow-auto bg-zinc-950 p-5 text-zinc-100">
            {loadingFile ? (
              <p className="font-mono text-xs text-zinc-400">Carregando arquivo...</p>
            ) : (
              <pre className="font-mono text-xs leading-relaxed whitespace-pre">
                <code>{content}</code>
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
