import { useEffect, useState } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export type InstallPlatform = 'mobile' | 'ios' | 'androidtv' | 'webos';

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroidTV, setIsAndroidTV] = useState(false);
  const [isWebOS, setIsWebOS] = useState(false);

  useEffect(() => {
    const win = window as unknown as {
      PalmSystem?: unknown;
      webOSSystem?: unknown;
      navigator: Navigator & { standalone?: boolean };
    };

    const checkStandalone = () =>
      window.matchMedia('(display-mode: standalone)').matches ||
      window.matchMedia('(display-mode: fullscreen)').matches ||
      window.matchMedia('(display-mode: minimal-ui)').matches ||
      win.navigator.standalone === true ||
      Boolean(win.PalmSystem || win.webOSSystem) ||
      window.navigator.userAgent.includes('TelaCastAndroidApp');

    setIsInstalled(checkStandalone());

    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    const onDisplayChange = () => setIsInstalled(checkStandalone());
    mediaQuery.addEventListener?.('change', onDisplayChange);

    const ua = window.navigator.userAgent;
    const uaLower = ua.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(uaLower));
    setIsWebOS(/web0s|webos|netcast|lg browser/i.test(ua));
    setIsAndroidTV(/android tv|googletv|bravia|aft[a-z0-9]|mibox|shield/i.test(uaLower));

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      mediaQuery.removeEventListener?.('change', onDisplayChange);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const detectedPlatform: InstallPlatform = isWebOS
    ? 'webos'
    : isAndroidTV
      ? 'androidtv'
      : isIOS
        ? 'ios'
        : 'mobile';

  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  return {
    isInstallable: Boolean(deferredPrompt),
    isInstalled,
    isIOS,
    isAndroidTV,
    isWebOS,
    detectedPlatform,
    install,
  };
}
