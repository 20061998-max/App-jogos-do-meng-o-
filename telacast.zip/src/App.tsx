/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { AdminView } from './components/AdminView';
import { AppShellView } from './components/AppShellView';
import { AppViewerView } from './components/AppViewerView';
import { CodeExplorerView } from './components/CodeExplorerView';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LandingView } from './components/LandingView';
import { MengaoShield } from './components/MengaoShield';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SubscriberView } from './components/SubscriberView';
import { usePWAInstall } from './hooks/usePWAInstall';
import {
  AppSettingsDoc,
  DEFAULT_PLANS,
  DEFAULT_SETTINGS,
  PlanItem,
  subscribePlans,
  subscribePublicSettings,
} from './lib/storeCatalog';
import { AppTab } from './types';

function MainApp() {
  const [activeTab, setActiveTab] = useState<AppTab>('inicio');
  const [preselectedPlan, setPreselectedPlan] = useState<string | undefined>(undefined);
  const [settings, setSettings] = useState<AppSettingsDoc>(DEFAULT_SETTINGS);
  const [plans, setPlans] = useState<PlanItem[]>(DEFAULT_PLANS);
  const { isInstalled } = usePWAInstall();

  useEffect(() => {
    const unsubSettings = subscribePublicSettings(setSettings);
    const unsubPlans = subscribePlans(activeTab === 'admin', setPlans);
    return () => {
      unsubSettings();
      unsubPlans();
    };
  }, [activeTab]);

  function handleNavigate(tab: AppTab, plan?: string) {
    if (plan) setPreselectedPlan(plan);
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Quando aberto pelo atalho/app instalado (standalone/fullscreen), funciona como o aplicativo
  if (isInstalled) {
    return <AppShellView settings={settings} plans={plans} />;
  }

  const navItems: { id: AppTab; label: string }[] = [
    { id: 'inicio', label: 'Vitrine' },
    { id: 'assistir', label: 'Assistir' },
    { id: 'assinante', label: 'Ativação' },
    { id: 'admin', label: 'Painel Admin' },
    { id: 'codigo', label: 'Código-Fonte' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      <header className="sticky top-0 z-30 border-b border-zinc-800 bg-zinc-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-3.5">
          {/* Zone 1: Brand mark */}
          <button
            type="button"
            onClick={() => handleNavigate('inicio')}
            className="inline-flex items-center gap-2.5 font-display text-xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            <MengaoShield className="h-7 w-7 shrink-0" />
            <span>{settings.appName}</span>
          </button>

          {/* Zone 2: Clean single-line text navigation links */}
          <nav className="flex items-center gap-6 overflow-x-auto text-sm font-medium">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
                    active
                      ? 'border-[#C8102E] text-white font-semibold'
                      : 'border-transparent text-zinc-400 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="hidden sm:flex items-center shrink-0">
            <PWAInstallButton variant="primary" label="Instalar App" />
          </div>
        </div>
      </header>

      <main className="flex-1">
        {activeTab === 'inicio' && (
          <LandingView settings={settings} plans={plans} onNavigate={handleNavigate} />
        )}
        {activeTab === 'assistir' && <AppViewerView />}
        {activeTab === 'assinante' && (
          <SubscriberView
            settings={settings}
            plans={plans}
            preselectedPlan={preselectedPlan}
          />
        )}
        {activeTab === 'admin' && <AdminView settings={settings} plans={plans} />}
        {activeTab === 'codigo' && <CodeExplorerView />}
      </main>

      <footer className="border-t border-zinc-800 bg-zinc-950">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-6 py-6 text-xs text-zinc-400 sm:flex-row sm:items-center">
          <span>
            {settings.appName} · Vitrine pública, gestão Google Admin e reprodução exclusiva no App e
            Smart TVs
          </span>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('codigo')}
              className="hover:text-white"
            >
              Explorar /web e /android
            </button>
            <a href="/api/download-projeto" className="hover:text-white">
              Baixar código-fonte (.zip)
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}
