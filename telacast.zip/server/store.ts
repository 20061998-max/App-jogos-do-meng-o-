import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export type UserRole = 'user' | 'admin';
export type SubscriptionStatus = 'ativo' | 'pendente' | 'vencido' | 'bloqueado';

export interface UserProfileRecord {
  id: string;
  nome: string;
  email: string;
  role: UserRole;
  status_assinatura: SubscriptionStatus;
  plano: string;
  expira_em: string | null;
  criado_em: string;
  passwordHash?: string;
}

export interface PaymentLogRecord {
  id: string;
  user_id: string;
  gateway: 'mercadopago' | 'asaas';
  evento_id: string;
  plano: string;
  status: string;
  processado_em: string;
}

export interface PublicAppConfig {
  whatsappNumber: string;
  pixKey: string;
  pixType: string;
  pixReceiverName: string;
  tvOnlyAntiRetransmission: boolean;
}

export interface AppDeviceRecord {
  deviceCode: string;
  platform: string;
  isTv: boolean;
  licenseActive: boolean;
  planName: string;
  isStreaming: boolean;
  firstSeenAt: string;
  lastSeenAt: string;
}

interface StoreData {
  profiles: UserProfileRecord[];
  pagamentos: PaymentLogRecord[];
  adminWhatsapp?: string;
  publicConfig?: PublicAppConfig;
  devices?: AppDeviceRecord[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

function daysFromNowIso(days: number): string {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
}

const DEFAULT_PUBLIC_CONFIG: PublicAppConfig = {
  whatsappNumber: (process.env.ADMIN_WHATSAPP || '').replace(/\D/g, ''),
  pixKey: '',
  pixType: 'Aleatória',
  pixReceiverName: 'Jogos do Mengão',
  tvOnlyAntiRetransmission: true,
};

const INITIAL_SUBSCRIBERS: UserProfileRecord[] = [
  {
    id: 'usr-1001',
    nome: 'Marina Albuquerque',
    email: 'marina.albuquerque@studio.com.br',
    role: 'user',
    status_assinatura: 'ativo',
    plano: '3 Meses',
    expira_em: daysFromNowIso(24),
    criado_em: daysFromNowIso(-36),
  },
  {
    id: 'usr-1002',
    nome: 'Rafael Mendonça',
    email: 'rafael.mendonca@edtech.com.br',
    role: 'user',
    status_assinatura: 'ativo',
    plano: '1 Ano',
    expira_em: daysFromNowIso(18),
    criado_em: daysFromNowIso(-12),
  },
  {
    id: 'usr-1003',
    nome: 'Camila Ferreira',
    email: 'camila.ferreira@eventos.net',
    role: 'user',
    status_assinatura: 'vencido',
    plano: '1 Mês',
    expira_em: daysFromNowIso(-4),
    criado_em: daysFromNowIso(-64),
  },
];

function ensureStore(): StoreData {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    const initial: StoreData = {
      profiles: INITIAL_SUBSCRIBERS,
      pagamentos: [],
      adminWhatsapp: (process.env.ADMIN_WHATSAPP || '').replace(/\D/g, ''),
      publicConfig: DEFAULT_PUBLIC_CONFIG,
      devices: [],
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as StoreData;
    return {
      profiles: Array.isArray(parsed.profiles) ? parsed.profiles : [],
      pagamentos: Array.isArray(parsed.pagamentos) ? parsed.pagamentos : [],
      adminWhatsapp: typeof parsed.adminWhatsapp === 'string' ? parsed.adminWhatsapp : '',
      publicConfig: parsed.publicConfig
        ? {
            whatsappNumber:
              parsed.publicConfig.whatsappNumber || parsed.adminWhatsapp || DEFAULT_PUBLIC_CONFIG.whatsappNumber,
            pixKey: parsed.publicConfig.pixKey || '',
            pixType: parsed.publicConfig.pixType || 'Aleatória',
            pixReceiverName: parsed.publicConfig.pixReceiverName || 'Jogos do Mengão',
            tvOnlyAntiRetransmission:
              typeof parsed.publicConfig.tvOnlyAntiRetransmission === 'boolean'
                ? parsed.publicConfig.tvOnlyAntiRetransmission
                : true,
          }
        : {
            ...DEFAULT_PUBLIC_CONFIG,
            whatsappNumber: parsed.adminWhatsapp || DEFAULT_PUBLIC_CONFIG.whatsappNumber,
          },
      devices: Array.isArray(parsed.devices) ? parsed.devices : [],
    };
  } catch {
    return {
      profiles: INITIAL_SUBSCRIBERS,
      pagamentos: [],
      adminWhatsapp: '',
      publicConfig: DEFAULT_PUBLIC_CONFIG,
      devices: [],
    };
  }
}

function saveStore(data: StoreData): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpFile = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DATA_FILE);
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, keyHex] = stored.split(':');
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return crypto.timingSafeEqual(keyBuf, derived);
}

export function sanitizeProfile(profile: UserProfileRecord) {
  const effectiveStatus =
    profile.status_assinatura === 'ativo' &&
    profile.expira_em &&
    new Date(profile.expira_em).getTime() <= Date.now()
      ? 'vencido'
      : profile.status_assinatura;

  const diasRestantes = profile.expira_em
    ? Math.max(
        0,
        Math.ceil((new Date(profile.expira_em).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      )
    : 0;

  return {
    id: profile.id,
    nome: profile.nome,
    email: profile.email,
    role: profile.role,
    status_assinatura: effectiveStatus,
    plano: profile.plano,
    expira_em: profile.expira_em,
    dias_restantes: effectiveStatus === 'ativo' ? diasRestantes : 0,
    criado_em: profile.criado_em,
  };
}

function syncExpiredProfiles(data: StoreData): StoreData {
  let changed = false;
  const now = Date.now();
  data.profiles = data.profiles.map((p) => {
    if (p.status_assinatura === 'ativo' && p.expira_em && new Date(p.expira_em).getTime() <= now) {
      changed = true;
      return { ...p, status_assinatura: 'vencido' };
    }
    return p;
  });
  if (changed) saveStore(data);
  return data;
}

export function listProfiles(searchQuery = ''): ReturnType<typeof sanitizeProfile>[] {
  const data = syncExpiredProfiles(ensureStore());
  const q = searchQuery.trim().toLowerCase();
  const list = q
    ? data.profiles.filter(
        (p) => p.nome.toLowerCase().includes(q) || p.email.toLowerCase().includes(q)
      )
    : data.profiles;
  return list.map(sanitizeProfile);
}

export function findProfileByEmail(email: string): UserProfileRecord | undefined {
  const data = syncExpiredProfiles(ensureStore());
  return data.profiles.find((p) => p.email.toLowerCase() === email.trim().toLowerCase());
}

export function findProfileById(id: string): UserProfileRecord | undefined {
  const data = syncExpiredProfiles(ensureStore());
  return data.profiles.find((p) => p.id === id);
}

export function hasClaimedAdmin(): boolean {
  const data = ensureStore();
  return data.profiles.some((p) => p.role === 'admin' && Boolean(p.passwordHash));
}

export function createUserProfile(input: {
  nome: string;
  email: string;
  password: string;
  role?: UserRole;
  plano?: string;
}): UserProfileRecord {
  const data = ensureStore();
  const normalizedEmail = input.email.trim().toLowerCase();
  if (data.profiles.some((p) => p.email.toLowerCase() === normalizedEmail)) {
    throw new Error('Já existe uma conta cadastrada com este e-mail.');
  }
  const created: UserProfileRecord = {
    id: `usr-${crypto.randomUUID().slice(0, 8)}`,
    nome: input.nome.trim(),
    email: normalizedEmail,
    role: input.role ?? 'user',
    status_assinatura: input.role === 'admin' ? 'ativo' : 'pendente',
    plano: input.plano ?? '1 Mês',
    expira_em: input.role === 'admin' ? daysFromNowIso(365) : null,
    criado_em: new Date().toISOString(),
    passwordHash: hashPassword(input.password),
  };
  data.profiles.unshift(created);
  saveStore(data);
  return created;
}

export function updateProfileById(
  id: string,
  updater: (current: UserProfileRecord) => UserProfileRecord
): UserProfileRecord | null {
  const data = ensureStore();
  const idx = data.profiles.findIndex((p) => p.id === id);
  if (idx === -1) return null;
  data.profiles[idx] = updater(data.profiles[idx]);
  saveStore(data);
  return data.profiles[idx];
}

export function activateSubscriptionDays(
  userId: string,
  days: number,
  plano?: string
): UserProfileRecord | null {
  return updateProfileById(userId, (current) => {
    const now = Date.now();
    const currentExp = current.expira_em ? new Date(current.expira_em).getTime() : 0;
    const baseMs = currentExp > now ? currentExp : now;
    const nextExp = new Date(baseMs + days * 24 * 60 * 60 * 1000).toISOString();
    return {
      ...current,
      status_assinatura: 'ativo',
      plano: plano ?? current.plano,
      expira_em: nextExp,
    };
  });
}

export function recordPaymentLog(entry: Omit<PaymentLogRecord, 'id' | 'processado_em'>): boolean {
  const data = ensureStore();
  if (data.pagamentos.some((p) => p.evento_id === entry.evento_id)) {
    return false;
  }
  data.pagamentos.unshift({
    id: `pay-${crypto.randomUUID().slice(0, 8)}`,
    ...entry,
    processado_em: new Date().toISOString(),
  });
  saveStore(data);
  return true;
}

export function listRecentPayments(): PaymentLogRecord[] {
  const data = ensureStore();
  return data.pagamentos.slice(0, 20);
}

export function getAdminWhatsapp(): string {
  const envNum = (process.env.ADMIN_WHATSAPP || '').replace(/\D/g, '');
  const data = ensureStore();
  const saved = (data.publicConfig?.whatsappNumber || data.adminWhatsapp || '').replace(/\D/g, '');
  return saved || envNum;
}

export function setAdminWhatsapp(rawPhone: string): string {
  const digits = rawPhone.replace(/\D/g, '').slice(0, 16);
  const data = ensureStore();
  data.adminWhatsapp = digits;
  data.publicConfig = {
    ...(data.publicConfig || DEFAULT_PUBLIC_CONFIG),
    whatsappNumber: digits,
  };
  saveStore(data);
  return digits;
}

export function getPublicAppConfig(): PublicAppConfig {
  const data = ensureStore();
  const cfg = data.publicConfig || DEFAULT_PUBLIC_CONFIG;
  return {
    ...cfg,
    whatsappNumber: getAdminWhatsapp(),
  };
}

export function updatePublicAppConfig(patch: Partial<PublicAppConfig>): PublicAppConfig {
  const data = ensureStore();
  const current = data.publicConfig || DEFAULT_PUBLIC_CONFIG;
  const nextWhatsapp =
    typeof patch.whatsappNumber === 'string'
      ? patch.whatsappNumber.replace(/\D/g, '').slice(0, 16)
      : current.whatsappNumber;

  const updated: PublicAppConfig = {
    whatsappNumber: nextWhatsapp,
    pixKey: typeof patch.pixKey === 'string' ? patch.pixKey.trim().slice(0, 140) : current.pixKey,
    pixType: typeof patch.pixType === 'string' ? patch.pixType.trim().slice(0, 20) : current.pixType,
    pixReceiverName:
      typeof patch.pixReceiverName === 'string'
        ? patch.pixReceiverName.trim().slice(0, 80)
        : current.pixReceiverName,
    tvOnlyAntiRetransmission:
      typeof patch.tvOnlyAntiRetransmission === 'boolean'
        ? patch.tvOnlyAntiRetransmission
        : current.tvOnlyAntiRetransmission,
  };
  data.adminWhatsapp = nextWhatsapp;
  data.publicConfig = updated;
  saveStore(data);
  return updated;
}

export function upsertDeviceHeartbeat(input: {
  deviceCode: string;
  platform: string;
  isTv: boolean;
  licenseActive: boolean;
  planName: string | null;
  isStreaming: boolean;
}): AppDeviceRecord {
  const code = input.deviceCode.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (!/^TC-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code)) {
    throw new Error('Código de aparelho inválido.');
  }

  const nowIso = new Date().toISOString();
  const data = ensureStore();
  const devices = data.devices || [];
  const idx = devices.findIndex((d) => d.deviceCode === code);

  const record: AppDeviceRecord = {
    deviceCode: code,
    platform: (input.platform || 'pwa').trim().slice(0, 24),
    isTv: Boolean(input.isTv),
    licenseActive: Boolean(input.licenseActive),
    planName: (input.planName || 'Aguardando').trim().slice(0, 60),
    isStreaming: Boolean(input.isStreaming),
    firstSeenAt: idx >= 0 ? devices[idx].firstSeenAt : nowIso,
    lastSeenAt: nowIso,
  };

  if (idx >= 0) {
    devices[idx] = record;
  } else {
    devices.unshift(record);
  }

  data.devices = devices.slice(0, 500);
  saveStore(data);
  return record;
}

export function getDeviceStats() {
  const data = ensureStore();
  const devices = [...(data.devices || [])].sort(
    (a, b) => new Date(b.lastSeenAt).getTime() - new Date(a.lastSeenAt).getTime()
  );
  const now = Date.now();
  const onlineThresholdMs = 3 * 60 * 1000;
  const onlineAgora = devices.filter(
    (d) => now - new Date(d.lastSeenAt).getTime() <= onlineThresholdMs
  ).length;
  const totalInstalados = devices.length;
  const ativosComLicenca = devices.filter((d) => d.licenseActive).length;
  const tvsConectadas = devices.filter((d) => d.isTv).length;
  const transmitindoAgora = devices.filter(
    (d) => d.isStreaming && now - new Date(d.lastSeenAt).getTime() <= onlineThresholdMs
  ).length;

  return {
    onlineAgora,
    totalInstalados,
    ativosComLicenca,
    tvsConectadas,
    transmitindoAgora,
    dispositivos: devices,
  };
}
